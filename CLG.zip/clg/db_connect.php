<?php
if (!session_id()) session_start();

$conn = new mysqli("localhost", "root", "", "college_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>