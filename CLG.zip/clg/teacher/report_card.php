<?php
if (!session_id()) session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: /clg/login.php");
    exit();
}

require_once '../db_connect.php';

$success = $error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save'])) {
    $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
    $student_id = (int)$_POST['student_id'];
    $subject_marks = [];
    $default_subjects = ['Python', 'Cyber_Security', 'Introduction_to_AI', 'J2EE'];
    foreach ($default_subjects as $subject) {
        $key = "subject_$subject";
        if (isset($_POST[$key]) && is_numeric($_POST[$key])) {
            $subject_marks[$subject] = floatval($_POST[$key]);
        } else {
            $subject_marks[$subject] = 0;
        }
    }
    $subject_marks_json = json_encode($subject_marks);
    $percentage = floatval($_POST['percentage']);
    $behavior = trim($_POST['behavior']);
    $comments = trim($_POST['comments'] ?? '');

    if ($id) {
        $sql = "UPDATE report_cards SET student_id = ?, subject_marks = ?, percentage = ?, behavior = ?, comments = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isdssi", $student_id, $subject_marks_json, $percentage, $behavior, $comments, $id);
    } else {
        $sql = "INSERT INTO report_cards (student_id, subject_marks, percentage, behavior, comments) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isdss", $student_id, $subject_marks_json, $percentage, $behavior, $comments);
    }
    
    if ($stmt->execute()) {
        $success = "Report card saved successfully";
    } else {
        $error = "Error saving report card: " . $conn->error;
    }
    $stmt->close();
} elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['generate_pdf'])) {
    require_once '../tcpdf/tcpdf.php';
    ob_end_clean();
    $student_id = (int)$_POST['student_id'];

    $sql = "SELECT s.name, s.roll_no, s.email, s.contact_no, r.* FROM report_cards r JOIN students s ON r.student_id = s.id 
            WHERE r.student_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $report = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($report) {
        $subject_marks = json_decode($report['subject_marks'], true) ?? [];
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('H N Shukla College Of IT & Mgmt');
        $pdf->SetTitle('Student Report Card');
        $pdf->SetSubject('Report Card');
        $pdf->SetHeaderData('', 0, 'H N Shukla College Of IT & Mgmt', 'Student Report Card | Generated: ' . date('d/m/Y h:i A'));
        $pdf->setHeaderFont(['helvetica', 'B', 12]);
        $pdf->setFooterFont(['helvetica', '', 10]);
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
        $pdf->SetMargins(15, 30, 15);
        $pdf->SetHeaderMargin(10);
        $pdf->SetFooterMargin(10);
        $pdf->SetAutoPageBreak(TRUE, 15);
        $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
        $pdf->AddPage();
        $pdf->SetFont('helvetica', '', 10);

        // Define colors
        $headerColor = [50, 50, 50]; // Dark Gray (RGB)
        $tableHeaderColor = [200, 220, 255]; // Light Blue (RGB)
        $textColor = [50, 50, 50]; // Dark Gray (RGB)

        // Header
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont('helvetica', 'B', 16);
        $pdf->Cell(0, 10, 'H N Shukla College Of IT & Mgmt', 0, 1, 'C');
        $pdf->SetFont('helvetica', '', 10);
        $pdf->Cell(0, 5, '2, Raiya Rd, Vaishali Nagar, Rajkot, Gujarat 360007', 0, 1, 'C');
        $pdf->Ln(10);

        // Invoice Title and Details
        $pdf->SetFont('helvetica', 'B', 20);
        $pdf->Cell(0, 10, 'REPORT CARD', 0, 1, 'C');
        $pdf->Ln(5);

        $pdf->SetFont('helvetica', '', 12);
        $pdf->SetTextColorArray($textColor);
        $pdf->Cell(90, 5, 'Report Card #: ' . $report['id'], 0, 0);
        $pdf->Cell(0, 5, 'Receiver:'.  $report['name'], 0, 1);
        $pdf->Cell(90, 5, 'Date: ' . date('d/m/Y'), 0, 0);
        $pdf->Cell(0, 5, 'Roll No.:'. $report['roll_no'], 0, 1);
        $pdf->Ln(5);

        // Student Details
        $pdf->SetFillColor(240, 240, 240);
        $pdf->Cell(0, 10, 'Student Details', 1, 1, 'L', true);
        $pdf->SetFillColor(255, 255, 255);
        $pdf->Cell(0, 5, 'Name: ' . htmlspecialchars($report['name']), 1, 1, 'L', true);
        $pdf->Cell(0, 5, 'Roll No: ' . htmlspecialchars($report['roll_no']), 1, 1, 'L', true);
        $pdf->Cell(0, 5, 'Email: ' . htmlspecialchars($report['email']), 1, 1, 'L', true);
        $pdf->Cell(0, 5, 'Contact No: ' . htmlspecialchars($report['contact_no'] ?? 'N/A'), 1, 1, 'L', true);
        $pdf->Ln(5);

        // Subject Marks Table
        $pdf->SetFillColor(200, 220, 255);
        $pdf->Cell(50, 10, 'Subject', 1, 0, 'C', true);
        $pdf->Cell(40, 10, 'Total Marks', 1, 0, 'C', true);
        $pdf->Cell(40, 10, 'Obtained Marks', 1, 0, 'C', true);
        $pdf->Cell(40, 10, 'Passing Marks', 1, 1, 'C', true);
        $pdf->SetFillColor(255, 255, 255);

        $default_subjects = ['Python', 'Cyber_Security', 'Introduction_to_AI', 'J2EE'];
        $total_obtained = 0;
        $total_possible = count($default_subjects) * 100;
        $passing_marks = 35; // Assuming 35% is passing

        foreach ($default_subjects as $subject) {
            $obtained = $subject_marks[$subject] ?? 0;
            $total_obtained += $obtained;
            $pdf->Cell(50, 10, htmlspecialchars($subject), 1, 0, 'L');
            $pdf->Cell(40, 10, '100', 1, 0, 'C');
            $pdf->Cell(40, 10, number_format($obtained, 2), 1, 0, 'C');
            $pdf->Cell(40, 10, number_format($passing_marks, 2), 1, 1, 'C');
        }

        // Summary Table
        $pdf->Ln(5);
        $pdf->SetFillColor(200, 220, 255);
        $pdf->Cell(70, 10, 'Description', 1, 0, 'C', true);
        $pdf->Cell(60, 10, 'Details', 1, 1, 'C', true);
        $pdf->SetFillColor(255, 255, 255);
        $percentage = ($total_obtained / $total_possible) * 100;
        $remarks = $percentage >= 35 ? 'Pass' : 'Fail';
        $pdf->Cell(70, 10, 'Total Marks', 1, 0, 'L');
        $pdf->Cell(60, 10, $total_obtained . ' / ' . $total_possible, 1, 1, 'C');
        $pdf->Cell(70, 10, 'Percentage', 1, 0, 'L');
        $pdf->Cell(60, 10, number_format($percentage, 2) . '%', 1, 1, 'C');
        $pdf->Cell(70, 10, 'Remarks', 1, 0, 'L');
        $pdf->Cell(60, 10, $remarks, 1, 1, 'C');

        // Footer
        $pdf->Ln(10);
        $pdf->SetFont('helvetica', 'I', 8);
        $pdf->Cell(0, 10, 'Kindly contact the college for payment details.', 0, 1, 'C');
        $pdf->Cell(0, 5, 'Contact: +12345 67890 | Email: hnshukla@gmail.com', 0, 1, 'C');
        $pdf->Cell(0, 5, 'Generated on: ' . date('d/m/Y h:i A'), 0, 1, 'C');

        $pdf->Output('report_card_' . $report['roll_no'] . '.pdf', 'D');
        exit();
    } else {
        $error = "No report card found for this student.";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_report'])) {
    $id = (int)$_POST['id'];
    $sql = "DELETE FROM report_cards WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $success = "Report card deleted successfully";
    } else {
        $error = "Error deleting report card: " . $conn->error;
    }
    $stmt->close();
}

$sql = "SELECT r.id, r.student_id, s.name, s.roll_no, s.email, s.contact_no, r.percentage, r.behavior, r.comments, r.subject_marks 
        FROM report_cards r JOIN students s ON r.student_id = s.id";
$stmt = $conn->prepare($sql);
$stmt->execute();
$report_cards = $stmt->get_result();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Report Cards</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }
        .modal-content {
            background: #fff;
            margin: 5% auto;
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
            position: relative;
        }
        .close-modal {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #dc3545;
        }
        .view-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .view-table th, .view-table td {
            border: 1px solid #e2e8f0;
            padding: 8px;
            text-align: left;
        }
        .view-table th {
            background: #f4f6f9;
            font-weight: 500;
        }
        #viewModal .view-table th,
        #viewModal .view-table td {
            color: #000000; /* Black color */
        }
    </style>
    <script>
        const defaultSubjects = ['Python', 'Cyber_Security', 'Introduction_to_AI', 'J2EE'];

        function resetReportForm() {
            const form = document.getElementById('report-card-form');
            const subjectsContainer = document.getElementById('subjects-container');
            const reportId = document.getElementById('report-id');
            const studentId = document.getElementById('student_id');
            const rollNo = document.getElementById('roll_no');
            const email = document.getElementById('email');
            const contactNo = document.getElementById('contact_no');
            const percentage = document.getElementById('percentage');
            const behavior = document.getElementById('behavior');
            const comments = document.getElementById('comments');

            reportId.value = '';
            subjectsContainer.innerHTML = '';
            studentId.selectedIndex = 0;
            rollNo.value = '';
            email.value = '';
            contactNo.value = '';
            percentage.value = '';
            behavior.value = '';
            comments.value = '';

            defaultSubjects.forEach(subject => {
                const div = document.createElement('div');
                div.className = 'form-group';
                const label = document.createElement('label');
                label.setAttribute('for', `subject_${subject}`);
                label.textContent = `${subject}: `;
                const input = document.createElement('input');
                input.type = 'number';
                input.name = `subject_${subject}`;
                input.id = `subject_${subject}`;
                input.min = 0;
                input.max = 100;
                input.step = 0.01;
                input.required = true;
                div.appendChild(label);
                div.appendChild(input);
                subjectsContainer.appendChild(div);
            });
            document.getElementById('form-title').textContent = 'Generate New Report Card';
            document.getElementById('report-form').style.display = 'block';
        }

        function fetchStudentDetails(select) {
            const rollNo = document.getElementById('roll_no');
            const email = document.getElementById('email');
            const contactNo = document.getElementById('contact_no');
            const option = select.options[select.selectedIndex];
            rollNo.value = option.getAttribute('data-roll_no');
            email.value = option.getAttribute('data-email');
            contactNo.value = option.getAttribute('data-contact_no');
        }

        function calculatePercentage() {
            const inputs = document.querySelectorAll('input[name^="subject_"]');
            let totalMarks = 0;
            let totalSubjects = defaultSubjects.length;

            inputs.forEach(input => {
                const value = parseFloat(input.value) || 0;
                if (!isNaN(value)) {
                    totalMarks += value;
                }
            });

            const percentage = totalSubjects > 0 ? (totalMarks / (totalSubjects * 100)) * 100 : 0;
            document.getElementById('percentage').value = percentage.toFixed(2);
        }

        function showViewModal(data) {
            const modal = document.getElementById('viewModal');
            const modalContent = document.getElementById('modalContent');
            const subjectMarks = JSON.parse(data.subject_marks.replace(/\\'/g, "'"));

            let html = `
                <h2>View Report Card</h2>
                <table class="view-table">
                    <tr><th>Student Name</th><td>${data.name}</td></tr>
                    <tr><th>Roll No</th><td>${data.roll_no}</td></tr>
                    <tr><th>Email</th><td>${data.email}</td></tr>
                    <tr><th>Contact No</th><td>${data.contact_no}</td></tr>
                    <tr><th>Percentage</th><td>${data.percentage}%</td></tr>
                    <tr><th>Behavior</th><td>${data.behavior}</td></tr>
                    <tr><th>Comments</th><td>${data.comments || 'N/A'}</td></tr>
                </table>
                <div style="margin-top: 20px;"></div> <!-- Space above Subject Marks -->
                <h3>Subject Marks</h3>
                <table class="view-table">
                    <tr><th>Subject</th><th>Marks</th></tr>
            `;
            defaultSubjects.forEach(subject => {
                html += `<tr><td>${subject}</td><td>${subjectMarks[subject] !== undefined ? subjectMarks[subject] : 'N/A'}</td></tr>`;
            });
            html += '</table>';
            // Calculate and display total marks
            let totalMarks = defaultSubjects.reduce((sum, subject) => sum + (subjectMarks[subject] !== undefined ? parseFloat(subjectMarks[subject]) || 0 : 0), 0);
            html += `<p style="margin-top: 10px; font-weight: bold;">Total Marks: ${totalMarks} out of ${defaultSubjects.length * 100}</p>`;

            modalContent.innerHTML = html;
            modal.style.display = 'block';
        }

        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.edit-report-btn').forEach(button => {
                button.addEventListener('click', () => {
                    const form = document.getElementById('report-card-form');
                    const subjectsContainer = document.getElementById('subjects-container');
                    const reportId = document.getElementById('report-id');
                    const studentId = document.getElementById('student_id');
                    const rollNo = document.getElementById('roll_no');
                    const email = document.getElementById('email');
                    const contactNo = document.getElementById('contact_no');
                    const percentage = document.getElementById('percentage');
                    const behavior = document.getElementById('behavior');
                    const comments = document.getElementById('comments');

                    reportId.value = button.getAttribute('data-id');
                    studentId.value = button.getAttribute('data-student_id');
                    rollNo.value = button.getAttribute('data-roll_no');
                    email.value = button.getAttribute('data-email');
                    contactNo.value = button.getAttribute('data-contact_no');
                    percentage.value = button.getAttribute('data-percentage');
                    behavior.value = button.getAttribute('data-behavior');
                    comments.value = button.getAttribute('data-comments');

                    subjectsContainer.innerHTML = '';
                    const subjectMarks = JSON.parse(button.getAttribute('data-subject_marks').replace(/\\'/g, "'"));
                    defaultSubjects.forEach(subject => {
                        const div = document.createElement('div');
                        div.className = 'form-group';
                        const label = document.createElement('label');
                        label.setAttribute('for', `subject_${subject}`);
                        label.textContent = `${subject}: `;
                        const input = document.createElement('input');
                        input.type = 'number';
                        input.name = `subject_${subject}`;
                        input.id = `subject_${subject}`;
                        input.min = 0;
                        input.max = 100;
                        input.step = 0.01;
                        input.required = true;
                        input.value = subjectMarks[subject] !== undefined ? subjectMarks[subject] : 0;
                        div.appendChild(label);
                        div.appendChild(input);
                        subjectsContainer.appendChild(div);
                    });

                    document.getElementById('form-title').textContent = 'Edit Report Card';
                    document.getElementById('report-form').style.display = 'block';
                });
            });

            document.querySelectorAll('.view-report-btn').forEach(button => {
                button.addEventListener('click', () => {
                    const data = {
                        id: button.getAttribute('data-id'),
                        name: button.getAttribute('data-name'),
                        roll_no: button.getAttribute('data-roll_no'),
                        email: button.getAttribute('data-email'),
                        contact_no: button.getAttribute('data-contact_no'),
                        percentage: button.getAttribute('data-percentage'),
                        behavior: button.getAttribute('data-behavior'),
                        comments: button.getAttribute('data-comments'),
                        subject_marks: button.getAttribute('data-subject_marks')
                    };
                    showViewModal(data);
                });
            });

            document.querySelector('.close-modal').addEventListener('click', () => {
                document.getElementById('viewModal').style.display = 'none';
            });
        });
    </script>
</head>
<body>
    <?php include '../sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Manage Report Cards</h1>
            <button id="sidebar-toggle" class="sidebar-toggle">☰</button>
        </div>
        <?php if ($success) { echo "<p class='success'>$success</p>"; } ?>
        <?php if ($error) { echo "<p class='error'>$error</p>"; } ?>
        
        <div class="report-card-container">
            <button class="btn" onclick="resetReportForm()">Generate Report Card</button>
            <div id="report-form" class="form-container" style="display:none;">
                <h2 id="form-title">Generate New Report Card</h2>
                <form id="report-card-form" method="POST" action="" class="report-card-form">
                    <input type="hidden" id="report-id" name="id">
                    <div class="form-group">
                        <label for="student_id">Select Student</label>
                        <select id="student_id" name="student_id" required onchange="fetchStudentDetails(this)">
                            <option value="" disabled selected>Select Student</option>
                            <?php
                            $students = $conn->query("SELECT id, name, roll_no, email, contact_no FROM students");
                            while ($row = $students->fetch_assoc()) { ?>
                                <option value="<?php echo $row['id']; ?>" 
                                        data-roll_no="<?php echo htmlspecialchars($row['roll_no']); ?>" 
                                        data-email="<?php echo htmlspecialchars($row['email']); ?>" 
                                        data-contact_no="<?php echo htmlspecialchars($row['contact_no'] ?? 'N/A'); ?>">
                                    <?php echo htmlspecialchars($row['name']); ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="roll_no">Roll No</label>
                            <input type="text" id="roll_no" name="roll_no" readonly>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" readonly>
                        </div>
                        <div class="form-group">
                            <label for="contact_no">Contact No</label>
                            <input type="text" id="contact_no" name="contact_no" readonly>
                        </div>
                    </div>
                    <div id="subjects-container"></div>
                    <div class="form-group">
                        <label for="percentage">Percentage</label>
                        <input type="number" id="percentage" name="percentage" step="0.01" min="0" max="100" readonly>
                    </div>
                    <div class="form-group">
                        <label for="behavior">Behavior</label>
                        <input type="text" id="behavior" name="behavior" required>
                    </div>
                    <div class="form-group">
                        <label for="comments">Comments</label>
                        <textarea id="comments" name="comments"></textarea>
                    </div>
                    <div class="form-actions">
                        <button type="button" onclick="calculatePercentage()" class="btn">Calculate Percentage</button>
                        <button type="submit" name="save" class="btn">Save Report Card</button>
                        <button type="button" class="btn btn-secondary" onclick="document.getElementById('report-form').style.display='none'">Cancel</button>
                    </div>
                </form>
            </div>
            <h2>All Report Cards</h2>
            <table id="report-cards-table">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Roll No</th>
                        <th>Email</th>
                        <th>Contact No</th>
                        <th>Percentage</th>
                        <th>Behavior</th>
                        <th>Comments</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($report_cards->num_rows > 0) {
                        while ($row = $report_cards->fetch_assoc()) { 
                            $subject_marks_json = json_encode(json_decode($row['subject_marks'], true) ?? [], JSON_HEX_APOS | JSON_HEX_QUOT);
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['roll_no']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['contact_no'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($row['percentage']); ?>%</td>
                                <td><?php echo htmlspecialchars($row['behavior']); ?></td>
                                <td><?php echo htmlspecialchars($row['comments'] ?? 'N/A'); ?></td>
                                <td class="actions">
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
                                        <button type="submit" name="generate_pdf" class="btn btn-small btn-secondary">PDF</button>
                                    </form>
                                    <button type="button" class="btn btn-small btn-secondary view-report-btn" 
                                            data-id="<?php echo $row['id']; ?>" 
                                            data-name="<?php echo htmlspecialchars(addslashes($row['name'])); ?>" 
                                            data-roll_no="<?php echo htmlspecialchars(addslashes($row['roll_no'])); ?>" 
                                            data-email="<?php echo htmlspecialchars(addslashes($row['email'])); ?>" 
                                            data-contact_no="<?php echo htmlspecialchars(addslashes($row['contact_no'] ?? 'N/A')); ?>" 
                                            data-percentage="<?php echo $row['percentage']; ?>" 
                                            data-behavior="<?php echo htmlspecialchars(addslashes($row['behavior'])); ?>" 
                                            data-comments="<?php echo htmlspecialchars(addslashes($row['comments'] ?? '')); ?>" 
                                            data-subject_marks='<?php echo $subject_marks_json; ?>'>View</button>
                                    <button type="button" class="btn btn-small btn-secondary edit-report-btn" 
                                            data-id="<?php echo $row['id']; ?>" 
                                            data-student_id="<?php echo $row['student_id']; ?>" 
                                            data-name="<?php echo htmlspecialchars(addslashes($row['name'])); ?>" 
                                            data-roll_no="<?php echo htmlspecialchars(addslashes($row['roll_no'])); ?>" 
                                            data-email="<?php echo htmlspecialchars(addslashes($row['email'])); ?>" 
                                            data-contact_no="<?php echo htmlspecialchars(addslashes($row['contact_no'] ?? 'N/A')); ?>" 
                                            data-subject_marks='<?php echo $subject_marks_json; ?>' 
                                            data-percentage="<?php echo $row['percentage']; ?>" 
                                            data-behavior="<?php echo htmlspecialchars(addslashes($row['behavior'])); ?>" 
                                            data-comments="<?php echo htmlspecialchars(addslashes($row['comments'] ?? '')); ?>">Edit</button>
                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this report?');">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" name="delete_report" class="btn btn-small btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php }
                    } else { ?>
                        <tr><td colspan="8">No report cards found</td></tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <div id="viewModal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div id="modalContent"></div>
        </div>
    </div>
</body>
</html>