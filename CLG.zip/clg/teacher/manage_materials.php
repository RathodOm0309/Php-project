<?php
if (!session_id()) session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: /clg/login.php");
    exit();
}

require_once '../db_connect.php';

$success = $error = "";
$upload_dir = "C:/xampp/htdocs/clg/Uploads/"; // Absolute path for server
$relative_upload_dir = "/clg/Uploads/"; // Relative path for DB

// Handle file serving for view and download
if (isset($_GET['action']) && isset($_GET['file_id'])) {
    $action = $_GET['action'];
    $file_id = (int)$_GET['file_id'];
    $user_id = (int)$_SESSION['user_id'];

    // Fetch file path from database
    $sql = "SELECT file_path FROM materials WHERE id = ? AND uploaded_by = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $file_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $file_path = $result->fetch_assoc()['file_path'];
        $absolute_file_path = str_replace($relative_upload_dir, $upload_dir, $file_path);

        if (file_exists($absolute_file_path)) {
            header('Content-Type: application/pdf');
            header('Content-Length: ' . filesize($absolute_file_path));
            if ($action === 'download') {
                header('Content-Disposition: attachment; filename="' . basename($absolute_file_path) . '"');
            } else {
                header('Content-Disposition: inline; filename="' . basename($absolute_file_path) . '"');
            }
            readfile($absolute_file_path);
            exit();
        } else {
            $error = "File not found on server.";
            error_log("File not found: $absolute_file_path");
        }
    } else {
        $error = "Invalid file ID or unauthorized access.";
        error_log("Invalid file_id: $file_id for user_id: $user_id");
    }
    $stmt->close();
}

// Validate user_id exists in users table
$user_id = (int)$_SESSION['user_id'];
$sql = "SELECT id, username FROM users WHERE id = ? AND role = 'teacher'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if (!$result->num_rows) {
    $error = "Invalid user ID ({$user_id}) for teacher role. Please log in again.";
    $stmt->close();
    error_log("Invalid user_id: {$user_id}, Session: " . print_r($_SESSION, true));
    header("Location: /clg/login.php?error=" . urlencode($error));
    exit();
}
$user = $result->fetch_assoc();
$username = $user['username'];
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_material'])) {
    $title = trim($_POST['title']);
    $file = $_FILES['file'];

    if ($file['error'] === UPLOAD_ERR_OK) {
        // Validate file type
        $allowed_types = ['application/pdf'];
        if (!in_array($file['type'], $allowed_types)) {
            $error = "Only PDF files are allowed.";
            error_log("Invalid file type: {$file['type']}");
        } else {
            // Generate timestamp-based filename
            $file_name = preg_replace("/[^a-zA-Z0-9.]/", "_", basename($file['name']));
            $timestamp = date('Ymd_His'); // Format: YYYYMMDD_HHMMSS
            $new_file_name = "{$timestamp}_{$file_name}";
            $target_file = $relative_upload_dir . $new_file_name; // Relative path for DB
            $absolute_target_file = $upload_dir . $new_file_name; // Absolute path for server

            // Ensure Uploads directory exists
            if (!is_dir($upload_dir)) {
                if (!mkdir($upload_dir, 0755, true)) {
                    $error = "Failed to create Uploads directory at $upload_dir.";
                    error_log("Directory creation failed: $upload_dir");
                }
            }

            if (!$error) {
                if (is_writable($upload_dir)) {
                    if (move_uploaded_file($file['tmp_name'], $absolute_target_file)) {
                        // Insert into database
                        $sql = "INSERT INTO materials (title, file_path, uploaded_by) VALUES (?, ?, ?)";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("ssi", $title, $target_file, $user_id);
                        if ($stmt->execute()) {
                            $success = "Material added successfully";
                            error_log("Material added: title=$title, file_path=$target_file, uploaded_by=$user_id");
                        } else {
                            $error = "Error adding material to database: " . $conn->error;
                            error_log("Database error: " . $conn->error);
                            // Remove uploaded file if DB insert fails
                            if (file_exists($absolute_file_path)) {
                                unlink($absolute_file_path);
                            }
                        }
                        $stmt->close();
                    } else {
                        $error = "Error moving uploaded file to $absolute_target_file. Check directory permissions.";
                        error_log("Upload error: Failed to move {$file['tmp_name']} to $absolute_target_file");
                    }
                } else {
                    $error = "Uploads directory ($upload_dir) is not writable.";
                    error_log("Permission error: $upload_dir is not writable");
                }
            }
        }
    } else {
        $error = "File upload failed with error code: " . $file['error'];
        error_log("Upload error code: " . $file['error']);
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_material'])) {
    $id = (int)$_POST['id'];
    $title = trim($_POST['title']);
    $old_file_path = $_POST['old_file_path'];
    $file = $_FILES['file'];
    $file_path = $old_file_path;

    if ($file['error'] === UPLOAD_ERR_OK) {
        // Validate file type
        $allowed_types = ['application/pdf'];
        if (!in_array($file['type'], $allowed_types)) {
            $error = "Only PDF files are allowed.";
            error_log("Invalid file type: {$file['type']}");
        } else {
            // Generate timestamp-based filename
            $file_name = preg_replace("/[^a-zA-Z0-9.]/", "_", basename($file['name']));
            $timestamp = date('Ymd_His'); // Format: YYYYMMDD_HHMMSS
            $new_file_name = "{$timestamp}_{$file_name}";
            $target_file = $relative_upload_dir . $new_file_name; // Relative path for DB
            $absolute_target_file = $upload_dir . $new_file_name; // Absolute path for server

            // Ensure Uploads directory exists
            if (!is_dir($upload_dir)) {
                if (!mkdir($upload_dir, 0755, true)) {
                    $error = "Failed to create Uploads directory at $upload_dir.";
                    error_log("Directory creation failed: $upload_dir");
                }
            }

            if (!$error) {
                if (is_writable($upload_dir)) {
                    if (move_uploaded_file($file['tmp_name'], $absolute_target_file)) {
                        // Delete old file
                        $absolute_old_file_path = str_replace($relative_upload_dir, $upload_dir, $old_file_path);
                        if (file_exists($absolute_old_file_path) && $old_file_path !== $target_file) {
                            unlink($absolute_old_file_path);
                        }
                        $file_path = $target_file;
                    } else {
                        $error = "Error moving uploaded file to $absolute_target_file. Check directory permissions.";
                        error_log("Upload error: Failed to move {$file['tmp_name']} to $absolute_target_file");
                    }
                } else {
                    $error = "Uploads directory ($upload_dir) is not writable.";
                    error_log("Permission error: $upload_dir is not writable");
                }
            }
        }
    }

    if (!$error) {
        $sql = "UPDATE materials SET title = ?, file_path = ?, uploaded_by = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssii", $title, $file_path, $user_id, $id);
        if ($stmt->execute()) {
            $success = "Material updated successfully";
            error_log("Material updated: id=$id, title=$title, file_path=$file_path, uploaded_by=$user_id");
        } else {
            $error = "Error updating material: " . $conn->error;
            error_log("Database error: " . $conn->error);
        }
        $stmt->close();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_material'])) {
    $id = (int)$_POST['id'];
    $sql = "SELECT file_path FROM materials WHERE id = ? AND uploaded_by = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $file_path = $result->fetch_assoc()['file_path'];
    $stmt->close();

    $sql = "DELETE FROM materials WHERE id = ? AND uploaded_by = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id, $user_id);
    if ($stmt->execute()) {
        $absolute_file_path = str_replace($relative_upload_dir, $upload_dir, $file_path);
        if (file_exists($absolute_file_path)) {
            unlink($absolute_file_path);
        }
        $success = "Material deleted successfully";
        error_log("Material deleted: id=$id, uploaded_by=$user_id");
    } else {
        $error = "Error deleting material: " . $conn->error;
        error_log("Database error: " . $conn->error);
    }
    $stmt->close();
}

$sql = "SELECT id, title, file_path FROM materials WHERE uploaded_by = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$materials = $stmt->get_result();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Materials</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
    <script>
        function editMaterial(id, title, filePath) {
            document.getElementById('edit-material-id').value = id;
            document.getElementById('edit-title').value = title;
            document.getElementById('edit-old_file_path').value = filePath;
            document.getElementById('edit-material-form').style.display = 'block';
            document.getElementById('add-material-form').style.display = 'none';
        }
    </script>
</head>
<body>
    <?php include '../sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Manage Materials</h1>
            <button id="sidebar-toggle" class="sidebar-toggle"><i class="fas fa-bars"></i></button>
        </div>
        <?php if ($success) { echo "<p class='success'>$success</p>"; } ?>
        <?php if ($error) { echo "<p class='error'>$error</p>"; } ?>
        
        <div class="material-container">
            <button class="btn" onclick="document.getElementById('add-material-form').style.display='block';document.getElementById('edit-material-form').style.display='none';">Add Material</button>
            <div id="add-material-form" class="form-container" style="display:none;">
                <h2>Add New Material</h2>
                <form method="POST" action="" class="material-form" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="title">Title</label>
                        <input type="text" id="title" name="title" required>
                    </div>
                    <div class="form-group">
                        <label for="file">Upload PDF File</label>
                        <input type="file" id="file" name="file" accept="application/pdf" required>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="add_material" class="btn">Add Material</button>
                        <button type="button" class="btn btn-secondary" onclick="this.closest('.form-container').style.display='none'">Cancel</button>
                    </div>
                </form>
            </div>
            <h2>Material List</h2>
            <table id="materials-table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($materials->num_rows > 0) {
                        while ($row = $materials->fetch_assoc()) {
                            $absolute_file_path = str_replace($relative_upload_dir, $upload_dir, $row['file_path']);
                            $file_exists = file_exists($absolute_file_path);
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['title']); ?></td>
                                <td class="actions">
                                    <?php if ($file_exists) { ?>
                                        <a href="?action=view&file_id=<?php echo $row['id']; ?>" target="_blank" class="btn btn-small btn-view">View</a>
                                        <a href="?action=download&file_id=<?php echo $row['id']; ?>" class="btn btn-small btn-secondary">Download</a>
                                    <?php } else { ?>
                                        <span class="error">File not found</span>
                                    <?php } ?>
                                    <button type="button" class="btn btn-small btn-secondary" onclick="editMaterial(<?php echo $row['id']; ?>, '<?php echo htmlspecialchars(addslashes($row['title'])); ?>', '<?php echo htmlspecialchars(addslashes($row['file_path'])); ?>')">Edit</button>
                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this material?');">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" name="delete_material" class="btn btn-small btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php }
                    } else { ?>
                        <tr><td colspan="2">No materials found</td></tr>
                    <?php } ?>
                </tbody>
            </table>
            <div id="edit-material-form" class="form-container" style="display:none;">
                <h2>Edit Material</h2>
                <form method="POST" action="" class="material-form" enctype="multipart/form-data">
                    <input type="hidden" id="edit-material-id" name="id">
                    <input type="hidden" id="edit-old_file_path" name="old_file_path">
                    <div class="form-group">
                        <label for="edit-title">Title</label>
                        <input type="text" id="edit-title" name="title" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-file">Upload New PDF File (leave blank to keep current)</label>
                        <input type="file" id="edit-file" name="file" accept="application/pdf">
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="edit_material" class="btn">Save Changes</button>
                        <button type="button" class="btn btn-secondary" onclick="this.closest('.form-container').style.display='none'">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>