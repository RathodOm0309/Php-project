<?php
if (!session_id()) session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: /clg/login.php?error=" . urlencode("Please log in as a teacher."));
    exit();
}

require_once '../db_connect.php';

$user_id = (int)$_SESSION['user_id'];

// Validate user_id exists in users table
$sql = "SELECT id, username FROM users WHERE id = ? AND role = 'teacher'";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("Prepare failed: " . $conn->error);
    header("Location: /clg/login.php?error=" . urlencode("Database error: " . $conn->error));
    exit();
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    error_log("Invalid user_id: {$user_id}, Session: " . print_r($_SESSION, true));
    $stmt->close();
    header("Location: /clg/login.php?error=" . urlencode("Invalid user ID for teacher role."));
    exit();
}
$username = $result->fetch_assoc()['username'];
$stmt->close();

$success = $error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_attendance'])) {
    $attendance_id = (int)$_POST['attendance_id'];
    $action = $_POST['edit_attendance']; // Get the action from the button value

    $conn->begin_transaction();
    try {
        $sql = "UPDATE attendance SET pending_status = ?, status = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        $new_pending_status = ($action === 'Confirm') ? 'Approved' : 'Declined';
        $new_status = ($action === 'Confirm') ? 'Present' : 'Absent';
        $stmt->bind_param("ssi", $new_pending_status, $new_status, $attendance_id);
        if (!$stmt->execute()) {
            throw new Exception("Error updating attendance: " . $conn->error);
        }
        $stmt->close();
        $conn->commit();
        $success = "Attendance " . ($action === 'Confirm' ? 'approved' : 'declined') . " successfully.";
        error_log("Attendance updated: id=$attendance_id, action=$action, pending_status=$new_pending_status, status=$new_status");
    } catch (Exception $e) {
        $conn->rollback();
        $error = "Error updating attendance: " . $e->getMessage();
        error_log("Attendance update error: " . $e->getMessage());
    }
}

// Fetch all attendance records
$sql = "SELECT a.id, a.student_id, a.date, a.status, a.pending_status, s.name AS student_name
        FROM attendance a
        JOIN students s ON a.student_id = s.id
        ORDER BY a.date DESC, s.name ASC";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("Prepare failed: " . $conn->error);
    $conn->close();
    header("Location: /clg/login.php?error=" . urlencode("Database error: " . $conn->error));
    exit();
}
$stmt->execute();
$attendance_records = $stmt->get_result();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Attendance - College Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
    <style>
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        .search-container {
            flex: 0 0 auto;
        }
        .search-container input {
            width: 200px;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }
        .search-container input:focus {
            outline: none;
            border-color: #007bff;
        }
        @media (max-width: 768px) {
            .search-container input {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <?php include '../sidebar.php'; ?> <!-- Adjusted path -->
    <div class="content">
        <div class="header">
            <h1>Manage Attendance</h1>
            <div class="search-container">
                <input type="text" id="search-input" placeholder="Search by student name (e.g., Me for Meet)">
            </div>
            <button id="sidebar-toggle" class="sidebar-toggle"><i class="fas fa-bars"></i></button>
        </div>
        <div class="attendance-container">
            <h2>Attendance Records</h2>
            <?php if ($success) { ?>
                <p class="success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?></p>
            <?php } ?>
            <?php if ($error) { ?>
                <p class="error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></p>
            <?php } ?>
            <div class="attendance-table-container">
                <table class="attendance-table">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Date</th>
                            <th>Requested Status</th>
                        </tr>
                    </thead>
                    <tbody id="attendance-table-body">
                        <?php if ($attendance_records->num_rows > 0) {
                            while ($row = $attendance_records->fetch_assoc()) { ?>
                                <tr class="table-row" data-student-name="<?php echo htmlspecialchars(strtolower($row['student_name'] ?? '')); ?>">
                                    <td><?php echo htmlspecialchars($row['student_name'] ?? 'Unknown'); ?></td>
                                    <td><?php echo htmlspecialchars($row['date'] ?? 'N/A'); ?></td>
                                    <td class="status-<?php echo strtolower($row['pending_status'] === 'Waiting' ? 'waiting' : strtolower($row['status'] ?? 'absent')); ?>">
                                        <i class="fas <?php 
                                            echo $row['pending_status'] === 'Waiting' ? 'fa-hourglass-half' : 
                                                ($row['status'] === 'Present' ? 'fa-check-circle' : 'fa-times-circle'); ?>"></i>
                                        <?php echo htmlspecialchars($row['pending_status'] === 'Waiting' ? 'Waiting for Approval' : ($row['status'] ?? 'Absent')); ?>
                                        <?php if ($row['pending_status'] === 'Waiting') { ?>
                                            <form method="POST" action="" style="display: inline; margin-left: 10px;">
                                                <input type="hidden" name="attendance_id" value="<?php echo htmlspecialchars($row['id']); ?>">
                                                <button type="submit" name="edit_attendance" value="Confirm" class="btn btn-small btn-confirm" style="margin-right: 5px;">
                                                    <i class="fas fa-check"></i> Approve
                                                </button>
                                                <button type="submit" name="edit_attendance" value="Decline" class="btn btn-small btn-decline">
                                                    <i class="fas fa-times"></i> Decline
                                                </button>
                                            </form>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php }
                        } else { ?>
                            <tr class="table-row"><td colspan="3">No attendance records found.</td></tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const searchInput = document.getElementById('search-input');
            const tableBody = document.getElementById('attendance-table-body');
            const rows = tableBody.querySelectorAll('.table-row');

            searchInput.addEventListener('input', () => {
                const searchTerm = searchInput.value.trim().toLowerCase();
                rows.forEach(row => {
                    const studentName = row.dataset.studentName || '';
                    if (searchTerm === '' || studentName.includes(searchTerm)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });

                const visibleRows = Array.from(rows).filter(row => row.style.display !== 'none');
                if (visibleRows.length === 0) {
                    if (!tableBody.querySelector('.no-records')) {
                        const noRecordsRow = document.createElement('tr');
                        noRecordsRow.className = 'table-row no-records';
                        noRecordsRow.innerHTML = '<td colspan="3">No matching attendance records found.</td>';
                        tableBody.appendChild(noRecordsRow);
                    }
                } else {
                    const noRecordsRow = tableBody.querySelector('.no-records');
                    if (noRecordsRow) {
                        noRecordsRow.remove();
                    }
                }
            });
        });
    </script>
</body>
</html>