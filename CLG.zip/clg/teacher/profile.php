<?php
// Start session if not already started
if (!session_id()) session_start();

// Redirect to login if user is not a teacher or session is invalid
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: /clg/login.php");
    exit();
}

// Include database connection
require_once '../db_connect.php';

$success = $error = "";
$user_id = (int)$_SESSION['user_id'];

/**
 * Validates user ID and fetches username from users table
 * @param mysqli $conn Database connection object
 * @param int $user_id User ID from session
 * @return array|null User data (id, username) or null if invalid
 */
function validateUser($conn, $user_id) {
    $sql = "SELECT id, username FROM users WHERE id = ? AND role = 'teacher'";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log("Prepare failed: " . $conn->error);
        return null;
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if (!$result->num_rows) {
        error_log("Invalid user_id: {$user_id}, Session: " . print_r($_SESSION, true));
        return null;
    }
    $user = $result->fetch_assoc();
    $stmt->close();
    return $user;
}

/**
 * Fetches teacher profile data from teacher_profiles table
 * @param mysqli $conn Database connection object
 * @param int $user_id User ID from session
 * @return array|null Profile data or null if not found
 */
function fetchTeacherProfile($conn, $user_id) {
    $sql = "SELECT name, marital_status, dob, experience_years, subject, profile_image FROM teacher_profiles WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log("Prepare failed: " . $conn->error);
        return null;
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $profile = $result->num_rows > 0 ? $result->fetch_assoc() : null;
    $stmt->close();
    return $profile;
}

// Validate user
$user = validateUser($conn, $user_id);
if (!$user) {
    $error = "Invalid user ID for teacher role. Please log in again.";
    header("Location: /clg/login.php?error=" . urlencode($error));
    exit();
}
$username = $user['username'];

// Fetch profile data
$profile = fetchTeacherProfile($conn, $user_id);

// Calculate profile completion percentage (exclude profile_image)
$fields = ['name', 'marital_status', 'dob', 'experience_years', 'subject'];
$filled_fields = 0;
$total_fields = count($fields);
if ($profile) {
    foreach ($fields as $field) {
        if (!empty($profile[$field]) || $profile[$field] === 0) { // Handle 0 for experience_years
            $filled_fields++;
        }
    }
}
$completion_percentage = ($filled_fields / $total_fields) * 100;
$incomplete_percentage = round(100 - $completion_percentage);

// Handle profile update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    // Sanitize and retrieve form inputs
    $name = trim($_POST['name']);
    $marital_status = $_POST['marital_status'] ?? null;
    $dob = $_POST['dob'] ? date('Y-m-d', strtotime($_POST['dob'])) : null;
    $experience_years = !empty($_POST['experience_years']) ? (int)$_POST['experience_years'] : null;
    $subject = trim($_POST['subject']);
    $file = $_FILES['profile_image'];
    $profile_image = $profile ? $profile['profile_image'] : null;

    // Validate inputs
    if (empty($name)) {
        $error = "Name is required.";
    } elseif (empty($subject)) {
        $error = "Subject is required.";
    } elseif (empty($marital_status)) {
        $error = "Marital status is required.";
    } elseif (empty($dob)) {
        $error = "Date of Birth is required.";
    } elseif (empty($experience_years) && $experience_years !== 0) {
        $error = "Experience is required.";
    } elseif ($file['error'] === UPLOAD_ERR_OK) {
        // Handle image upload
        $file_name = preg_replace("/[^a-zA-Z0-9.]/", "_", basename($file['name']));
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $target_dir = "../Uploads/";
        if (!in_array($file['type'], $allowed_types)) {
            $error = "Only JPEG, PNG, or GIF images are allowed.";
        } elseif ($file['size'] > 2 * 1024 * 1024) { // 2MB limit
            $error = "Image size must not exceed 2MB.";
        } else {
            if (!is_dir($target_dir)) {
                if (!mkdir($target_dir, 0755, true)) {
                    $error = "Failed to create Uploads directory.";
                }
            }
            if (!$error) {
                $profile_image = $target_dir . uniqid() . '_' . $file_name;
                if (!is_writable($target_dir)) {
                    $error = "Uploads directory is not writable.";
                } elseif (!move_uploaded_file($file['tmp_name'], $profile_image)) {
                    $error = "Error uploading image.";
                } elseif ($profile && $profile['profile_image'] && file_exists($profile['profile_image']) && $profile['profile_image'] != $profile_image) {
                    unlink($profile['profile_image']); // Delete old image
                }
            }
        }
    }

    // Update or insert profile if no errors
    if (!$error) {
        if ($profile) {
            // Update existing profile
            $sql = "UPDATE teacher_profiles SET name = ?, marital_status = ?, dob = ?, experience_years = ?, subject = ?, profile_image = ? WHERE user_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssissi", $name, $marital_status, $dob, $experience_years, $subject, $profile_image, $user_id);
        } else {
            // Insert new profile
            $sql = "INSERT INTO teacher_profiles (user_id, name, marital_status, dob, experience_years, subject, profile_image) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isssiss", $user_id, $name, $marital_status, $dob, $experience_years, $subject, $profile_image);
        }
        if ($stmt->execute()) {
            $success = "Profile updated successfully";
            // Refresh profile data
            $profile = fetchTeacherProfile($conn, $user_id);
            $filled_fields = 0;
            foreach ($fields as $field) {
                if (!empty($profile[$field]) || $profile[$field] === 0) {
                    $filled_fields++;
                }
            }
            $completion_percentage = ($filled_fields / $total_fields) * 100;
            $incomplete_percentage = round(100 - $completion_percentage);
        } else {
            $error = "Error updating profile: " . $conn->error;
        }
        $stmt->close();
    }
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Profile - College Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
</head>
<body>
    <!-- Include sidebar navigation -->
    <?php include '../sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Teacher Profile</h1>
            <button id="sidebar-toggle" class="sidebar-toggle"><i class="fas fa-bars"></i></button>
        </div>
        <!-- Display success or error messages -->
        <?php if ($success) { echo "<p class='success'>$success</p>"; } ?>
        <?php if ($error) { echo "<p class='error'>$error</p>"; } ?>
        <?php if ($completion_percentage < 100) { ?>
            <p class="error">Your profile is <?php echo $incomplete_percentage; ?>% incomplete. Please complete all required fields.</p>
        <?php } ?>
        <div class="profile-container">
            <?php if ($profile && $completion_percentage == 100) { ?>
                <div class="profile-card">
                    <!-- Display profile image or default -->
                    <img src="<?php echo htmlspecialchars($profile['profile_image'] ?: '/clg/Uploads/profile.jpg'); ?>" alt="Profile Image" class="profile-image">
                    <h2><?php echo htmlspecialchars($profile['name']); ?></h2>
                    <table class="profile-table">
                        <tbody>
                            <!-- Personal Details Section -->
                            <tr class="section-header">
                                <th colspan="2">Personal Details</th>
                            </tr>
                            <tr>
                                <td class="label">Username</td>
                                <td class="value"><?php echo htmlspecialchars($username); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Name</td>
                                <td class="value"><?php echo htmlspecialchars($profile['name']); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Marital Status</td>
                                <td class="value"><?php echo htmlspecialchars($profile['marital_status'] ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Date of Birth</td>
                                <td class="value"><?php echo $profile['dob'] ? date('d/m/Y', strtotime($profile['dob'])) : 'N/A'; ?></td>
                            </tr>
                            <!-- Professional Details Section -->
                            <tr class="section-header">
                                <th colspan="2">Professional Details</th>
                            </tr>
                            <tr>
                                <td class="label">Experience</td>
                                <td class="value"><?php echo htmlspecialchars($profile['experience_years'] ?? 'N/A') . ' years'; ?></td>
                            </tr>
                            <tr>
                                <td class="label">Subject</td>
                                <td class="value"><?php echo htmlspecialchars($profile['subject'] ?: 'N/A'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="form-actions">
                        <button class="btn" onclick="document.getElementById('edit-profile-form').style.display='block'">Edit Profile</button>
                    </div>
                </div>
            <?php } else { ?>
                <div class="form-actions">
                    <button class="btn" onclick="document.getElementById('edit-profile-form').style.display='block'">Complete Your Profile</button>
                </div>
            <?php } ?>
            <!-- Profile edit form -->
            <div id="edit-profile-form" class="form-container" style="display:none;">
                <h2><?php echo $profile ? 'Edit Profile' : 'Create Profile'; ?></h2>
                <form method="POST" action="" class="profile-form" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="profile_image">Profile Image (JPEG/PNG/GIF, max 2MB, optional)</label>
                        <input type="file" id="profile_image" name="profile_image" accept="image/jpeg,image/png,image/gif">
                    </div>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" value="<?php echo $profile ? htmlspecialchars($profile['name']) : ''; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="marital_status">Marital Status</label>
                        <select id="marital_status" name="marital_status" required>
                            <option value="" <?php echo !$profile || !$profile['marital_status'] ? 'selected' : ''; ?>>Select</option>
                            <option value="Single" <?php echo $profile && $profile['marital_status'] == 'Single' ? 'selected' : ''; ?>>Single</option>
                            <option value="Married" <?php echo $profile && $profile['marital_status'] == 'Married' ? 'selected' : ''; ?>>Married</option>
                            <option value="Divorced" <?php echo $profile && $profile['marital_status'] == 'Divorced' ? 'selected' : ''; ?>>Divorced</option>
                            <option value="Widowed" <?php echo $profile && $profile['marital_status'] == 'Widowed' ? 'selected' : ''; ?>>Widowed</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="dob">Date of Birth</label>
                        <input type="date" id="dob" name="dob" value="<?php echo $profile && $profile['dob'] ? htmlspecialchars($profile['dob']) : ''; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="experience_years">Experience (Years)</label>
                        <input type="number" id="experience_years" name="experience_years" min="0" value="<?php echo $profile ? htmlspecialchars($profile['experience_years'] ?? '') : ''; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="subject">Subject</label>
                        <input type="text" id="subject" name="subject" value="<?php echo $profile ? htmlspecialchars($profile['subject']) : ''; ?>" required>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="update_profile" class="btn">Save Profile</button>
                        <button type="button" class="btn btn-secondary" onclick="this.closest('.form-container').style.display='none'">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>