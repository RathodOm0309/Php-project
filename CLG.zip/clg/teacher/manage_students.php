<?php
if (!session_id()) session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: /clg/login.php");
    exit();
}

require_once '../db_connect.php';

$success = $error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_student'])) {
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $name = trim($_POST['name']);
    $roll_no = trim($_POST['roll_no']);
    $email = trim($_POST['email']);
    $contact_no = !empty($_POST['contact_no']) ? trim($_POST['contact_no']) : null;

    // Check for duplicate username in users
    $sql = "SELECT id FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        $error = "Username '$username' already exists.";
        $stmt->close();
    } else {
        $stmt->close();
        // Check for duplicate roll_no in students
        $sql = "SELECT id FROM students WHERE roll_no = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $roll_no);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $error = "Roll No '$roll_no' already exists.";
            $stmt->close();
        } else {
            $stmt->close();
            // Start transaction
            $conn->begin_transaction();
            try {
                // Insert into users table
                $sql = "INSERT INTO users (username, password, role) VALUES (?, ?, 'student')";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $username, $password);
                if (!$stmt->execute()) {
                    throw new Exception("Error adding user: " . $conn->error);
                }
                $user_id = $conn->insert_id;
                $stmt->close();

                // Insert into students table
                $sql = "INSERT INTO students (username, name, roll_no, email, contact_no) VALUES (?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sssss", $username, $name, $roll_no, $email, $contact_no);
                if (!$stmt->execute()) {
                    throw new Exception("Error adding student: " . $conn->error);
                }
                $conn->commit();
                $success = "Student added successfully";
                error_log("Student added: username=$username, roll_no=$roll_no, user_id=$user_id");
            } catch (Exception $e) {
                $conn->rollback();
                $error = $e->getMessage();
                error_log("Add student error: " . $e->getMessage());
            }
            $stmt->close();
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_student'])) {
    $id = (int)$_POST['id'];
    $username = trim($_POST['username']);
    $name = trim($_POST['name']);
    $roll_no = trim($_POST['roll_no']);
    $email = trim($_POST['email']);
    $contact_no = !empty($_POST['contact_no']) ? trim($_POST['contact_no']) : null;
    $password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null;

    // Get current student data to compare
    $sql = "SELECT username, roll_no FROM students WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $current_student = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // Check for duplicate username (exclude current student's user record)
    if ($username !== $current_student['username']) {
        $sql = "SELECT id FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $error = "Username '$username' is already taken.";
            $stmt->close();
        } else {
            $stmt->close();
        }
    }

    // Check for duplicate roll_no (exclude current student)
    if (!$error && $roll_no !== $current_student['roll_no']) {
        $sql = "SELECT id FROM students WHERE roll_no = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $roll_no);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $error = "Roll No '$roll_no' already exists.";
            $stmt->close();
        } else {
            $stmt->close();
        }
    }

    if (!$error) {
        $conn->begin_transaction();
        try {
            // Get current username from students to find corresponding user
            $sql = "SELECT username FROM students WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $current_username = $stmt->get_result()->fetch_assoc()['username'];
            $stmt->close();

            // Update users table
            $sql = $password ? 
                "UPDATE users SET username = ?, password = ? WHERE username = ? AND role = 'student'" :
                "UPDATE users SET username = ? WHERE username = ? AND role = 'student'";
            $stmt = $conn->prepare($sql);
            if ($password) {
                $stmt->bind_param("sss", $username, $password, $current_username);
            } else {
                $stmt->bind_param("ss", $username, $current_username);
            }
            if (!$stmt->execute()) {
                throw new Exception("Error updating user: " . $conn->error);
            }
            $stmt->close();

            // Update students table
            $sql = "UPDATE students SET username = ?, name = ?, roll_no = ?, email = ?, contact_no = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssi", $username, $name, $roll_no, $email, $contact_no, $id);
            if (!$stmt->execute()) {
                throw new Exception("Error updating student: " . $conn->error);
            }
            $conn->commit();
            $success = "Student updated successfully";
            error_log("Student updated: id=$id, username=$username, roll_no=$roll_no");
        } catch (Exception $e) {
            $conn->rollback();
            $error = $e->getMessage();
            error_log("Edit student error: " . $e->getMessage());
        }
        $stmt->close();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_student'])) {
    $id = (int)$_POST['id'];
    $conn->begin_transaction();
    try {
        // Get username from students to delete from users
        $sql = "SELECT username FROM students WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $username = $stmt->get_result()->fetch_assoc()['username'];
        $stmt->close();

        // Check for dependent records in report_cards
        $sql = "SELECT id FROM report_cards WHERE student_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            throw new Exception("Cannot delete student: Report card records exist.");
        }
        $stmt->close();

        // Delete from students
        $sql = "DELETE FROM students WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        if (!$stmt->execute()) {
            throw new Exception("Error deleting student: " . $conn->error);
        }
        $stmt->close();

        // Delete from users
        $sql = "DELETE FROM users WHERE username = ? AND role = 'student'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        if (!$stmt->execute()) {
            throw new Exception("Error deleting user: " . $conn->error);
        }
        $stmt->close();

        $conn->commit();
        $success = "Student deleted successfully";
        error_log("Student deleted: id=$id, username=$username");
    } catch (Exception $e) {
        $conn->rollback();
        $error = $e->getMessage();
        error_log("Delete student error: " . $e->getMessage());
    }
}

$sql = "SELECT id, username, name, roll_no, email, contact_no FROM students";
$stmt = $conn->prepare($sql);
$stmt->execute();
$students = $stmt->get_result();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
</head>
<body>
    <?php include '../sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Manage Students</h1>
            <button id="sidebar-toggle" class="sidebar-toggle">☰</button>
        </div>
        <?php if ($success) { echo "<p class='success'>$success</p>"; } ?>
        <?php if ($error) { echo "<p class='error'>$error</p>"; } ?>
        
        <div class="student-container">
            <button class="btn" onclick="document.getElementById('add-student-form').style.display='block'">Add Student</button>
            <div id="add-student-form" class="form-container" style="display:none;">
                <h2>Add New Student</h2>
                <form method="POST" action="" class="student-form">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="roll_no">Roll No</label>
                        <input type="text" id="roll_no" name="roll_no" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="contact_no">Contact No (Optional)</label>
                        <input type="text" id="contact_no" name="contact_no">
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="add_student" class="btn">Add Student</button>
                        <button type="button" class="btn btn-secondary" onclick="this.closest('.form-container').style.display='none'">Cancel</button>
                    </div>
                </form>
            </div>
            <h2>Student List</h2>
            <table id="students-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Roll No</th>
                        <th>Email</th>
                        <th>Contact No</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($students->num_rows > 0) {
                        while ($row = $students->fetch_assoc()) { ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['roll_no']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['contact_no'] ?? 'N/A'); ?></td>
                                <td class="actions">
                                    <button type="button" class="btn btn-small btn-secondary" onclick="editStudent(<?php echo $row['id']; ?>, '<?php echo htmlspecialchars(addslashes($row['username'])); ?>', '<?php echo htmlspecialchars(addslashes($row['name'])); ?>', '<?php echo htmlspecialchars(addslashes($row['roll_no'])); ?>', '<?php echo htmlspecialchars(addslashes($row['email'])); ?>', '<?php echo htmlspecialchars(addslashes($row['contact_no'] ?? 'N/A')); ?>')">Edit</button>
                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this student?');">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" name="delete_student" class="btn btn-small btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php }
                    } else { ?>
                        <tr><td colspan="5">No students found</td></tr>
                    <?php } ?>
                </tbody>
            </table>
            <div id="edit-student-form" class="form-container" style="display:none;">
                <h2>Edit Student</h2>
                <form method="POST" action="" class="student-form">
                    <input type="hidden" id="edit-id" name="id">
                    <div class="form-group">
                        <label for="edit-username">Username</label>
                        <input type="text" id="edit-username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-password">Password (leave blank to keep current)</label>
                        <input type="password" id="edit-password" name="password">
                    </div>
                    <div class="form-group">
                        <label for="edit-name">Name</label>
                        <input type="text" id="edit-name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-roll_no">Roll No</label>
                        <input type="text" id="edit-roll_no" name="roll_no" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-email">Email</label>
                        <input type="email" id="edit-email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-contact_no">Contact No (Optional)</label>
                        <input type="text" id="edit-contact_no" name="contact_no">
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="edit_student" class="btn">Save Changes</button>
                        <button type="button" class="btn btn-secondary" onclick="this.closest('.form-container').style.display='none'">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>