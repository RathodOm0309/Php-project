<?php
if (!session_id()) session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: /clg/login.php?error=" . urlencode("Please log in as a teacher."));
    exit();
}
require_once '../db_connect.php';

$success = $error = "";

// Fetch subjects and faculty for dropdowns with error handling
$sql = "SELECT id, name FROM subjects ORDER BY name";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    $error = "Database error: Subjects table not found. Please ensure the database is set up correctly. Contact admin.";
    $subjects = [];
} else {
    $stmt->execute();
    $subjects = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

$sql = "SELECT id, name FROM faculty ORDER BY name";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    $error = "Database error: Faculty table not found. Please ensure the database is set up correctly. Contact admin.";
    $faculty = [];
} else {
    $stmt->execute();
    $faculty = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

// Handle timetable form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_timetable'])) {
    $date = trim($_POST['date']);
    $slots = $_POST['slots'];
    $edit_date = isset($_POST['edit_date']) ? trim($_POST['edit_date']) : '';

    if (empty($date)) {
        $error = "Date is required.";
    } else {
        $conn->begin_transaction();
        try {
            if ($edit_date) {
                // Delete existing timetable for the date
                $sql = "DELETE FROM timetables WHERE date = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $edit_date);
                $stmt->execute();
                $stmt->close();
            }

            // Insert new timetable slots
            $sql = "INSERT INTO timetables (date, start_time, end_time, subject_id, teacher_id) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            foreach ($slots as $slot) {
                if (!empty($slot['start_time']) && !empty($slot['end_time']) && !empty($slot['subject_id']) && !empty($slot['teacher_id'])) {
                    $start_time = date("H:i:s", strtotime($slot['start_time']));
                    $end_time = date("H:i:s", strtotime($slot['end_time']));
                    $stmt->bind_param("sssii", $date, $start_time, $end_time, $slot['subject_id'], $slot['teacher_id']);
                    $stmt->execute();
                }
            }
            $stmt->close();
            $conn->commit();
            $success = $edit_date ? "Timetable updated successfully." : "Timetable added successfully.";
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Error saving timetable: " . $e->getMessage();
            error_log("Timetable error: " . $e->getMessage());
        }
    }
}

// Handle subject form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_subject'])) {
    $name = trim($_POST['name']);
    $edit_id = isset($_POST['edit_id']) ? (int)$_POST['edit_id'] : 0;

    if (empty($name)) {
        $error = "Subject name is required.";
    } else {
        if ($edit_id) {
            $sql = "UPDATE subjects SET name = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $name, $edit_id);
        } else {
            $sql = "INSERT INTO subjects (name) VALUES (?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $name);
        }
        if ($stmt->execute()) {
            $success = $edit_id ? "Subject updated successfully." : "Subject added successfully.";
            $subjects = $conn->query("SELECT id, name FROM subjects ORDER BY name")->fetch_all(MYSQLI_ASSOC);
        } else {
            $error = "Error saving subject: " . $conn->error;
        }
        $stmt->close();
    }
}

// Handle faculty form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_faculty'])) {
    $name = trim($_POST['name']);
    $edit_id = isset($_POST['edit_id']) ? (int)$_POST['edit_id'] : 0;

    if (empty($name)) {
        $error = "Faculty name is required.";
    } else {
        if ($edit_id) {
            $sql = "UPDATE faculty SET name = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $name, $edit_id);
        } else {
            $sql = "INSERT INTO faculty (name) VALUES (?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $name);
        }
        if ($stmt->execute()) {
            $success = $edit_id ? "Faculty updated successfully." : "Faculty added successfully.";
            $faculty = $conn->query("SELECT id, name FROM faculty ORDER BY name")->fetch_all(MYSQLI_ASSOC);
        } else {
            $error = "Error saving faculty: " . $conn->error;
        }
        $stmt->close();
    }
}

// Handle delete subject
if (isset($_GET['delete_subject'])) {
    $id = (int)$_GET['delete_subject'];
    $sql = "DELETE FROM subjects WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $success = "Subject deleted successfully.";
        $subjects = $conn->query("SELECT id, name FROM subjects ORDER BY name")->fetch_all(MYSQLI_ASSOC);
    } else {
        $error = "Error deleting subject: " . $conn->error;
    }
    $stmt->close();
}

// Handle delete faculty
if (isset($_GET['delete_faculty'])) {
    $id = (int)$_GET['delete_faculty'];
    $sql = "DELETE FROM faculty WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $success = "Faculty deleted successfully.";
        $faculty = $conn->query("SELECT id, name FROM faculty ORDER BY name")->fetch_all(MYSQLI_ASSOC);
    } else {
        $error = "Error deleting faculty: " . $conn->error;
    }
    $stmt->close();
}

// Handle delete timetable
if (isset($_GET['delete_timetable'])) {
    $date = trim($_GET['delete_timetable']);
    $sql = "DELETE FROM timetables WHERE date = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $date);
    if ($stmt->execute()) {
        $success = "Timetable for $date deleted successfully.";
    } else {
        $error = "Error deleting timetable: " . $conn->error;
    }
    $stmt->close();
}

// Fetch all timetables
$sql = "SELECT t.date, TIME(t.start_time) AS start_time, TIME(t.end_time) AS end_time, s.name AS subject, f.name AS teacher 
        FROM timetables t 
        JOIN subjects s ON t.subject_id = s.id 
        JOIN faculty f ON t.teacher_id = f.id 
        ORDER BY t.date DESC, t.start_time";
$timetables = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);
$grouped_timetables = [];
foreach ($timetables as $row) {
    $grouped_timetables[$row['date']][] = $row;
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Timetable - College Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
</head>
<body>
    <?php include '../sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Manage Timetable</h1>
            <button id="sidebar-toggle" class="sidebar-toggle"><i class="fas fa-bars"></i></button>
        </div>
        <?php if ($success) { echo "<p class='success'><i class='fas fa-check-circle'></i> $success</p>"; } ?>
        <?php if ($error) { echo "<p class='error'><i class='fas fa-exclamation-circle'></i> $error</p>"; } ?>
        <div class="timetable-container">
            <div class="group-actions">
                <button class="btn" id="add-timetable-btn"><i class="fas fa-plus"></i> Add Timetable</button>
                <button class="btn" id="manage-subjects-btn"><i class="fas fa-book"></i> Manage Subjects</button>
                <button class="btn" id="manage-faculty-btn"><i class="fas fa-users"></i> Manage Faculty</button>
            </div>
            <div id="timetable-form-container" class="form-container" style="display:none;">
                <h2 id="timetable-form-title">Add Timetable</h2>
                <form method="POST" action="" class="timetable-form">
                    <div class="form-group">
                        <label for="date">Date</label>
                        <input type="date" id="date" name="date" required>
                        <input type="hidden" id="edit-date" name="edit_date">
                    </div>
                    <div id="timetable-slots">
                        <div class="timetable-slot">
                            <div class="form-group">
                                <label for="slot-0-start_time">Time From</label>
                                <input type="time" name="slots[0][start_time]" id="slot-0-start_time" min="08:00" max="18:00" step="300" required>
                            </div>
                            <div class="form-group">
                                <label for="slot-0-end_time">Time To</label>
                                <input type="time" name="slots[0][end_time]" id="slot-0-end_time" min="08:00" max="18:00" step="300" required>
                            </div>
                            <div class="form-group">
                                <label for="slot-0-subject_id">Subject</label>
                                <select name="slots[0][subject_id]" id="slot-0-subject_id" required>
                                    <option value="">Select Subject</option>
                                    <?php foreach ($subjects as $subject) { ?>
                                        <option value="<?php echo $subject['id']; ?>"><?php echo htmlspecialchars($subject['name']); ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="slot-0-teacher_id">Faculty</label>
                                <select name="slots[0][teacher_id]" id="slot-0-teacher_id" required>
                                    <option value="">Select Teacher</option>
                                    <?php foreach ($faculty as $teacher) { ?>
                                        <option value="<?php echo $teacher['id']; ?>"><?php echo htmlspecialchars($teacher['name']); ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="timetable-actions">
                        <button type="submit" name="submit_timetable" class="btn btn-primary"><i class="fas fa-save"></i> Save</button>
                        <button type="button" id="cancel-timetable" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</button>
                    </div>
                </form>
            </div>
            <div id="subject-form-container" class="form-container" style="display:none;">
                <h2>Manage Subjects</h2>
                <form method="POST" action="" class="timetable-form">
                    <input type="hidden" id="edit-subject-id" name="edit_id">
                    <div class="form-group">
                        <label for="subject-name">Subject Name</label>
                        <input type="text" id="subject-name" name="name" required>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="submit_subject" class="btn btn-primary"><i class="fas fa-save"></i> Save</button>
                        <button type="button" id="cancel-subject" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</button>
                    </div>
                </form>
                <div id="subjects-table-container" style="display:none;">
                    <table class="timetable-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($subjects as $subject) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($subject['name']); ?></td>
                                    <td class="actions">
                                        <button class="btn btn-secondary edit-subject-btn" data-id="<?php echo $subject['id']; ?>" data-name="<?php echo htmlspecialchars($subject['name']); ?>"><i class="fas fa-edit"></i> Edit</button>
                                        <a href="?delete_subject=<?php echo $subject['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this subject?');"><i class="fas fa-trash"></i> Delete</a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div id="faculty-form-container" class="form-container" style="display:none;">
                <h2>Manage Faculty</h2>
                <form method="POST" action="" class="timetable-form">
                    <input type="hidden" id="edit-faculty-id" name="edit_id">
                    <div class="form-group">
                        <label for="faculty-name">Faculty Name</label>
                        <input type="text" id="faculty-name" name="name" required>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="submit_faculty" class="btn btn-primary"><i class="fas fa-save"></i> Save</button>
                        <button type="button" id="cancel-faculty" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</button>
                    </div>
                </form>
                <div id="faculty-table-container" style="display:none;">
                    <table class="timetable-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($faculty as $teacher) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($teacher['name']); ?></td>
                                    <td class="actions">
                                        <button class="btn btn-secondary edit-teacher-btn" data-id="<?php echo $teacher['id']; ?>" data-name="<?php echo htmlspecialchars($teacher['name']); ?>"><i class="fas fa-edit"></i> Edit</button>
                                        <a href="?delete_faculty=<?php echo $teacher['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this faculty?');"><i class="fas fa-trash"></i> Delete</a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="timetable-table-container">
                <?php foreach ($grouped_timetables as $date => $slots) { ?>
                    <div class="timetable-grid">
                        <div class="time-slot">
                            <h3><?php echo htmlspecialchars(date('d/m/Y', strtotime($date))); ?></h3>
                            <a href="?delete_timetable=<?php echo htmlspecialchars($date); ?>" class="btn btn-danger" style="margin-top: 10px;" onclick="return confirm('Are you sure you want to delete this timetable?');"><i class="fas fa-trash"></i> Delete</a>
                        </div>
                        <?php foreach ($slots as $slot) { ?>
                            <div class="time-slot">
                                <p><strong>Time:</strong> <?php echo htmlspecialchars(date('h:i A', strtotime($slot['start_time']))) . ' - ' . htmlspecialchars(date('h:i A', strtotime($slot['end_time']))); ?></p>
                                <p><strong>Subject:</strong> <?php echo htmlspecialchars($slot['subject']); ?></p>
                                <p><strong>Teacher:</strong> <?php echo htmlspecialchars($slot['teacher']); ?></p>
                            </div>
                        <?php } ?>
                    </div>
                <?php } ?>
                <?php if (empty($grouped_timetables)) { echo "<p class='info'><i class='fas fa-info-circle'></i> No timetables available.</p>"; } ?>
            </div>
        </div>
    </div>
    <script>
document.addEventListener('DOMContentLoaded', () => {
    const addTimetableBtn = document.getElementById('add-timetable-btn');
    const timetableFormContainer = document.getElementById('timetable-form-container');
    const cancelTimetableBtn = document.getElementById('cancel-timetable');
    const manageSubjectsBtn = document.getElementById('manage-subjects-btn');
    const manageFacultyBtn = document.getElementById('manage-faculty-btn');
    const subjectFormContainer = document.getElementById('subject-form-container');
    const facultyFormContainer = document.getElementById('faculty-form-container');
    const cancelSubjectBtn = document.getElementById('cancel-subject');
    const cancelFacultyBtn = document.getElementById('cancel-faculty');
    const subjectsTableContainer = document.getElementById('subjects-table-container');
    const facultyTableContainer = document.getElementById('faculty-table-container');
    const timetableTable = document.querySelector('.timetable-table');

    // Toggle timetable form
    if (addTimetableBtn && timetableFormContainer) {
        addTimetableBtn.addEventListener('click', () => {
            timetableFormContainer.style.display = 'block';
            timetableFormContainer.scrollIntoView({ behavior: 'smooth' });
            document.getElementById('timetable-form-title').textContent = 'Add Timetable';
            document.getElementById('timetable-form').reset();
            document.getElementById('edit-date').value = '';
            document.getElementById('date').readOnly = false;
            const slotsContainer = document.getElementById('timetable-slots');
            slotsContainer.innerHTML = createInitialSlots(2); // Start with 2 slots
        });
        if (cancelTimetableBtn) {
            cancelTimetableBtn.addEventListener('click', () => {
                timetableFormContainer.style.display = 'none';
                document.getElementById('timetable-form').reset();
                const slotsContainer = document.getElementById('timetable-slots');
                slotsContainer.innerHTML = createInitialSlots(2);
            });
        }
    }

    // Dynamic slot addition
    const timetableForm = document.getElementById('timetable-form');
    if (timetableForm) {
        const slotsContainer = document.getElementById('timetable-slots');
        let slotCount = 2; // Start with 2 slots

        function createInitialSlots(count) {
            let html = '';
            for (let i = 0; i < count; i++) {
                html += createSlotHtml(i);
            }
            return html;
        }

        function createSlotHtml(index) {
            return `
                <div class="timetable-slot">
                    <div class="form-group">
                        <label for="slot-${index}-start_time">Time From</label>
                        <input type="time" name="slots[${index}][start_time]" id="slot-${index}-start_time" min="08:00" max="18:00" step="300" required>
                    </div>
                    <div class="form-group">
                        <label for="slot-${index}-end_time">Time To</label>
                        <input type="time" name="slots[${index}][end_time]" id="slot-${index}-end_time" min="08:00" max="18:00" step="300" required>
                    </div>
                    <div class="form-group">
                        <label for="slot-${index}-subject_id">Subject</label>
                        <select name="slots[${index}][subject_id]" id="slot-${index}-subject_id" required>
                            <option value="">Select Subject</option>
                            <?php foreach ($subjects as $subject) { ?>
                                <option value="<?php echo $subject['id']; ?>"><?php echo htmlspecialchars($subject['name']); ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="slot-${index}-teacher_id">Faculty</label>
                        <select name="slots[${index}][teacher_id]" id="slot-${index}-teacher_id" required>
                            <option value="">Select Teacher</option>
                            <?php foreach ($faculty as $teacher) { ?>
                                <option value="<?php echo $teacher['id']; ?>"><?php echo htmlspecialchars($teacher['name']); ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
            `;
        }

        slotsContainer.addEventListener('input', (e) => {
            if (slotCount >= 5) return; // Limit to 5 slots
            const slots = slotsContainer.querySelectorAll('.timetable-slot');
            const lastSlot = slots[slots.length - 1];
            const inputs = lastSlot.querySelectorAll('input, select');
            const allFilled = Array.from(inputs).every(input => input.value);
            if (slots.length === slotCount && allFilled) {
                slotCount++;
                const newSlot = document.createElement('div');
                newSlot.className = 'timetable-slot';
                newSlot.innerHTML = createSlotHtml(slotCount - 1);
                slotsContainer.appendChild(newSlot);
            }
        });
    }

    // Edit timetable (disabled as per request)
    if (timetableTable) {
        timetableTable.addEventListener('click', (e) => {
            const editBtn = e.target.closest('.edit-timetable-btn');
            if (editBtn) {
                e.preventDefault(); // Disable edit functionality
            }
        });
    }

    // Toggle subject and faculty tables
    if (manageSubjectsBtn && subjectsTableContainer) {
        manageSubjectsBtn.addEventListener('click', () => {
            subjectsTableContainer.style.display = subjectsTableContainer.style.display === 'none' ? 'block' : 'none';
            subjectsTableContainer.scrollIntoView({ behavior: 'smooth' });
        });
    }

    if (manageFacultyBtn && facultyTableContainer) {
        manageFacultyBtn.addEventListener('click', () => {
            facultyTableContainer.style.display = facultyTableContainer.style.display === 'none' ? 'block' : 'none';
            facultyTableContainer.scrollIntoView({ behavior: 'smooth' });
        });
    }

    // Toggle subject form
    if (manageSubjectsBtn && subjectFormContainer) {
        manageSubjectsBtn.addEventListener('click', () => {
            subjectFormContainer.style.display = 'block';
            subjectFormContainer.scrollIntoView({ behavior: 'smooth' });
            document.getElementById('subject-name').value = '';
            document.getElementById('edit-subject-id').value = '';
        });
        if (cancelSubjectBtn) {
            cancelSubjectBtn.addEventListener('click', () => {
                subjectFormContainer.style.display = 'none';
                document.getElementById('subject-name').value = '';
                document.getElementById('edit-subject-id').value = '';
            });
        }
    }

    // Toggle faculty form
    if (manageFacultyBtn && facultyFormContainer) {
        manageFacultyBtn.addEventListener('click', () => {
            facultyFormContainer.style.display = 'block';
            facultyFormContainer.scrollIntoView({ behavior: 'smooth' });
            document.getElementById('faculty-name').value = '';
            document.getElementById('edit-faculty-id').value = '';
        });
        if (cancelFacultyBtn) {
            cancelFacultyBtn.addEventListener('click', () => {
                facultyFormContainer.style.display = 'none';
                document.getElementById('faculty-name').value = '';
                document.getElementById('edit-faculty-id').value = '';
            });
        }
    }

    // Edit functionality for subjects and faculty
    document.querySelectorAll('.edit-subject-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            const name = btn.dataset.name;
            document.getElementById('edit-subject-id').value = id;
            document.getElementById('subject-name').value = name;
            subjectFormContainer.style.display = 'block';
            subjectFormContainer.scrollIntoView({ behavior: 'smooth' });
        });
    });

    document.querySelectorAll('.edit-teacher-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            const name = btn.dataset.name;
            document.getElementById('edit-faculty-id').value = id;
            document.getElementById('faculty-name').value = name;
            facultyFormContainer.style.display = 'block';
            facultyFormContainer.scrollIntoView({ behavior: 'smooth' });
        });
    });
});
</script>
</body>
</html>