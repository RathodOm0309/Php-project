document.addEventListener('DOMContentLoaded', () => {
    console.log('scripts.js loaded');

    // Sidebar toggle
    const sidebar = document.querySelector('.sidebar');
    const content = document.querySelector('.content');
    const toggleButton = document.querySelector('#sidebar-toggle');
    if (toggleButton && sidebar && content) {
        toggleButton.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            content.classList.toggle('full-width');
            console.log('Sidebar toggled');
        });
    }

    // Submenu toggle
    const menuToggles = document.querySelectorAll('.menu-toggle');
    menuToggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
            const submenu = toggle.nextElementSibling;
            const isActive = submenu.classList.contains('active');
            // Close all other submenus
            document.querySelectorAll('.submenu.active').forEach(menu => {
                if (menu !== submenu) {
                    menu.classList.remove('active');
                    menu.previousElementSibling.classList.remove('active');
                }
            });
            // Toggle current submenu
            submenu.classList.toggle('active');
            toggle.classList.toggle('active');
            console.log(`Submenu toggled: ${isActive ? 'closed' : 'opened'}`);
        });
    });

    // Toggle timetable form
    const addTimetableBtn = document.getElementById('add-timetable-btn');
    const timetableFormContainer = document.getElementById('timetable-form-container');
    const cancelTimetableBtn = document.getElementById('cancel-timetable');
    if (addTimetableBtn && timetableFormContainer) {
        addTimetableBtn.addEventListener('click', () => {
            timetableFormContainer.style.display = 'block';
            timetableFormContainer.scrollIntoView({ behavior: 'smooth' });
            document.getElementById('timetable-form-title').textContent = 'Add Timetable';
            document.getElementById('timetable-form').reset();
            document.getElementById('edit-date').value = '';
            const slotsContainer = document.getElementById('timetable-slots');
            slotsContainer.innerHTML = createInitialSlots();
        });
        if (cancelTimetableBtn) {
            cancelTimetableBtn.addEventListener('click', () => {
                timetableFormContainer.style.display = 'none';
                document.getElementById('timetable-form').reset();
                document.getElementById('timetable-slots').innerHTML = createInitialSlots();
            });
        }
    }

    // Dynamic slot addition
    const timetableForm = document.getElementById('timetable-form');
    if (timetableForm) {
        const slotsContainer = document.getElementById('timetable-slots');
        let slotCount = 2;

        function createInitialSlots() {
            let html = '';
            for (let i = 0; i < 2; i++) {
                html += createSlotHtml(i);
            }
            return html;
        }

        function createSlotHtml(index) {
            return `
                <div class="timetable-slot">
                    <div class="form-group">
                        <label for="slot-${index}-start_time">Time From</label>
                        <input type="time" name="slots[${index}][start_time]" id="slot-${index}-start_time" min="08:00" max="17:00" step="300">
                    </div>
                    <div class="form-group">
                        <label for="slot-${index}-end_time">Time To</label>
                        <input type="time" name="slots[${index}][end_time]" id="slot-${index}-end_time" min="08:00" max="17:00" step="300">
                    </div>
                    <div class="form-group">
                        <label for="slot-${index}-subject_id">Subject</label>
                        <select name="slots[${index}][subject_id]" id="slot-${index}-subject_id">
                            <option value="">Select Subject</option>
                            ${document.querySelector('#slot-0-subject_id').innerHTML}
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="slot-${index}-teacher_id">Faculty</label>
                        <select name="slots[${index}][teacher_id]" id="slot-${index}-teacher_id">
                            <option value="">Select Teacher</option>
                            ${document.querySelector('#slot-0-teacher_id').innerHTML}
                        </select>
                    </div>
                </div>
            `;
        }

        slotsContainer.addEventListener('input', (e) => {
            if (slotCount >= 5) return;
            const slots = slotsContainer.querySelectorAll('.timetable-slot');
            const lastSlot = slots[slots.length - 1];
            const inputs = lastSlot.querySelectorAll('input, select');
            const allFilled = Array.from(inputs).every(input => input.value);
            if (slots.length === slotCount && allFilled) {
                slotCount++;
                const newSlot = document.createElement('div');
                newSlot.className = 'timetable-slot';
                newSlot.innerHTML = createSlotHtml(slotCount - 1);
                slotsContainer.appendChild(newSlot);
            }
        });
    }

    // Toggle timetable sections
    function toggleSection(element) {
        const table = element.nextElementSibling;
        table.style.display = table.style.display === 'none' ? 'table' : 'none';
        element.classList.toggle('collapsed');
    }

    // Edit timetable
    const timetableTable = document.querySelector('.timetable-table');
    if (timetableTable) {
        timetableTable.addEventListener('click', (e) => {
            const editBtn = e.target.closest('.edit-timetable-btn');
            if (editBtn) {
                const date = editBtn.dataset.date;
                fetch(`/clg/teacher/timetable/get_timetable.php?date=${encodeURIComponent(date)}`)
                    .then(response => response.json())
                    .then(data => {
                        timetableFormContainer.style.display = 'block';
                        document.getElementById('timetable-form-title').textContent = 'Edit Timetable';
                        document.getElementById('edit-date').value = date;
                        document.getElementById('date').value = date;
                        document.getElementById('date').readOnly = true;
                        const slotsContainer = document.getElementById('timetable-slots');
                        slotsContainer.innerHTML = '';
                        data.slots.forEach((slot, index) => {
                            const slotDiv = document.createElement('div');
                            slotDiv.className = 'timetable-slot';
                            slotDiv.innerHTML = `
                                <div class="form-group">
                                    <label for="slot-${index}-start_time">Time From</label>
                                    <input type="time" name="slots[${index}][start_time]" id="slot-${index}-start_time" value="${slot.start_time}" min="08:00" max="17:00" step="300" required>
                                </div>
                                <div class="form-group">
                                    <label for="slot-${index}-end_time">Time To</label>
                                    <input type="time" name="slots[${index}][end_time]" id="slot-${index}-end_time" value="${slot.end_time}" min="08:00" max="17:00" step="300" required>
                                </div>
                                <div class="form-group">
                                    <label for="slot-${index}-subject_id">Subject</label>
                                    <select name="slots[${index}][subject_id]" id="slot-${index}-subject_id" required>
                                        <option value="">Select Subject</option>
                                        ${document.querySelector('#slot-0-subject_id').innerHTML}
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="slot-${index}-teacher_id">Faculty</label>
                                    <select name="slots[${index}][teacher_id]" id="slot-${index}-teacher_id" required>
                                        <option value="">Select Teacher</option>
                                        ${document.querySelector('#slot-0-teacher_id').innerHTML}
                                    </select>
                                </div>
                            `;
                            slotsContainer.appendChild(slotDiv);
                            document.getElementById(`slot-${index}-subject_id`).value = slot.subject_id;
                            document.getElementById(`slot-${index}-teacher_id`).value = slot.teacher_id;
                        });
                        slotCount = data.slots.length;
                        if (slotCount < 5) {
                            const newSlot = document.createElement('div');
                            newSlot.className = 'timetable-slot';
                            newSlot.innerHTML = createSlotHtml(slotCount);
                            slotsContainer.appendChild(newSlot);
                            slotCount++;
                        }
                        timetableFormContainer.scrollIntoView({ behavior: 'smooth' });
                    })
                    .catch(error => {
                        console.error('Error fetching timetable:', error);
                        alert('Failed to load timetable data.');
                    });
            }
        });
    }

    // Subject and teacher modals
    const subjectTable = document.querySelector('.subjects-table');
    if (subjectTable) {
        subjectTable.addEventListener('click', (e) => {
            const editBtn = e.target.closest('.edit-subject-btn');
            if (editBtn) {
                const data = editBtn.dataset;
                const modal = document.getElementById('edit-subject-modal');
                document.getElementById('edit-subject-id').value = data.id;
                document.getElementById('edit-subject-name').value = data.name;
                modal.style.display = 'flex';
                modal.querySelector('.modal-content').scrollIntoView({ behavior: 'smooth' });
            }
        });
    }

    const teacherTable = document.querySelector('.faculty-table');
    if (teacherTable) {
        teacherTable.addEventListener('click', (e) => {
            const editBtn = e.target.closest('.edit-teacher-btn');
            if (editBtn) {
                const data = editBtn.dataset;
                const modal = document.getElementById('edit-teacher-modal');
                document.getElementById('edit-teacher-id').value = data.id;
                document.getElementById('edit-teacher-name').value = data.name;
                modal.style.display = 'flex';
                modal.querySelector('.modal-content').scrollIntoView({ behavior: 'smooth' });
            }
        });
    }

    // Close modals
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', () => {
            btn.closest('.modal').style.display = 'none';
        });
    });

    // Existing form validations
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value.trim();
            if (username === '' || password === '') {
                e.preventDefault();
                alert('Please fill in both username and password.');
            }
        });
    }

    const studentForms = document.querySelectorAll('.student-form');
    studentForms.forEach(form => {
        form.addEventListener('submit', (e) => {
            const username = form.querySelector('input[name="username"]');
            const name = form.querySelector('input[name="name"]');
            const email = form.querySelector('input[name="email"]');
            const roll_no = form.querySelector('input[name="roll_no"]');
            const contact_no = form.querySelector('input[name="contact_no"]');
            if (username && username.value.trim() === '') {
                e.preventDefault();
                alert('Username is required.');
            }
            if (name && name.value.trim() === '') {
                e.preventDefault();
                alert('Name is required.');
            }
            if (email && email.value.trim() !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
                e.preventDefault();
                alert('Please enter a valid email address.');
            }
            if (roll_no && roll_no.value.trim() === '') {
                e.preventDefault();
                alert('Roll No is required.');
            }
            if (contact_no && contact_no.value.trim() !== '' && !/^\+?\d{10,15}$/.test(contact_no.value)) {
                e.preventDefault();
                alert('Please enter a valid contact number.');
            }
        });
    });

    const materialForms = document.querySelectorAll('.material-form');
    materialForms.forEach(form => {
        form.addEventListener('submit', (e) => {
            const title = form.querySelector('input[name="title"]');
            const file = form.querySelector('input[name="file"]');
            if (title && title.value.trim() === '') {
                e.preventDefault();
                alert('Title is required.');
            }
            if (file && file.files.length === 0 && !form.querySelector('input[name="old_file_path"]')) {
                e.preventDefault();
                alert('Please select a PDF file.');
            }
        });
    });

    const reportCardForm = document.getElementById('report-card-form');
    if (reportCardForm) {
        reportCardForm.addEventListener('submit', (e) => {
            console.log('Report card form submitted');
            const percentage = document.getElementById('percentage');
            const subjectFields = document.querySelectorAll('input[type="number"][name^="subject_"]');
            const behavior = document.getElementById('behavior');
            subjectFields.forEach(field => {
                if (field.value === '' || field.value < 0 || field.value > 100) {
                    e.preventDefault();
                    alert(`${field.name.replace('subject_', '').replace('_', ' ')} must be between 0 and 100.`);
                }
            });
            if (percentage && (percentage.value === '' || percentage.value < 0 || percentage.value > 100)) {
                e.preventDefault();
                alert('Please calculate a valid percentage.');
            }
            if (behavior && behavior.value.trim() === '') {
                e.preventDefault();
                alert('Behavior is required.');
            }
        });
    }

    const profileForm = document.querySelector('.profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', (e) => {
            const name = profileForm.querySelector('input[name="name"]');
            const subject = profileForm.querySelector('input[name="subject"]');
            const dob = profileForm.querySelector('input[name="dob"]');
            const experience = profileForm.querySelector('input[name="experience_years"]');
            const file = profileForm.querySelector('input[name="profile_image"]');
            if (name && name.value.trim() === '') {
                e.preventDefault();
                alert('Name is required.');
            }
            if (subject && subject.value.trim() === '') {
                e.preventDefault();
                alert('Subject is required.');
            }
            if (dob && dob.value !== '') {
                const dobDate = new Date(dob.value);
                const today = new Date();
                if (dobDate > today) {
                    e.preventDefault();
                    alert('Date of Birth cannot be in the future.');
                }
            }
            if (experience && experience.value !== '' && (experience.value < 0 || experience.value > 50)) {
                e.preventDefault();
                alert('Experience must be between 0 and 50 years.');
            }
            if (file && file.files.length > 0) {
                const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
                if (!allowedTypes.includes(file.files[0].type)) {
                    e.preventDefault();
                    alert('Only JPEG, PNG, or GIF images are allowed.');
                }
                if (file.files[0].size > 2 * 1024 * 1024) {
                    e.preventDefault();
                    alert('Profile image must not exceed 2MB.');
                }
            }
        });
    }
});

// Existing functions
function fetchStudentDetails(select) {
    console.log('fetchStudentDetails called with student_id:', select.value);
    const selectedOption = select.options[select.selectedIndex];
    if (selectedOption) {
        document.getElementById('roll_no').value = selectedOption.getAttribute('data-roll_no') || '';
        document.getElementById('email').value = selectedOption.getAttribute('data-email') || '';
        document.getElementById('contact_no').value = selectedOption.getAttribute('data-contact_no') || '';
        console.log('Student details set:', {
            roll_no: selectedOption.getAttribute('data-roll_no'),
            email: selectedOption.getAttribute('data-email'),
            contact_no: selectedOption.getAttribute('data-contact_no')
        });
    } else {
        console.warn('No student selected');
    }
}

function updateSubjects(semester) {
    console.log('updateSubjects called with semester:', semester);
    const subjectsContainer = document.getElementById('subjects-container');
    if (!subjectsContainer) {
        console.error('subjects-container not found');
        alert('Error: Subjects container not found. Please check the page structure.');
        return;
    }
    subjectsContainer.innerHTML = '';
    const subjectsBySemester = {
        '1': ['HTML', 'Computer Fundamentals', 'Programming in C'],
        '2': ['SAD', 'Web Programming', 'Data Structure', 'COA'],
        '3': ['Networking', 'WordPress', 'Oracle', 'C++'],
        '4': ['Unix', 'SEO', 'Java', 'C#.Net'],
        '5': ['J2EE', 'Python', 'Cyber Security', 'Introduction to AI'],
        '6': ['ML', 'Android', 'Data Warehouse']
    };
    const subjects = subjectsBySemester[semester] || [];
    subjects.forEach(subject => {
        const cleanSubject = subject.replace(/[^a-zA-Z0-9]/g, '_');
        const div = document.createElement('div');
        div.className = 'form-group';
        div.innerHTML = `
            <label for="subject_${cleanSubject}" class="block text-gray-700">${subject} (out of 100)</label>
            <input type="number" id="subject_${cleanSubject}" name="subject_${cleanSubject}" 
                   step="0.01" min="0" max="100" class="w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" required>
        `;
        subjectsContainer.appendChild(div);
        console.log(`Added subject field: subject_${cleanSubject}`);
    });
}

function calculatePercentage() {
    console.log('calculatePercentage called');
    const subjectFields = document.querySelectorAll('#subjects-container input[type="number"]');
    let total = 0, count = 0;
    subjectFields.forEach(field => {
        const value = parseFloat(field.value) || 0;
        if (value >= 0 && value <= 100) {
            total += value;
            count++;
        }
    });
    const percentage = count > 0 ? (total / count).toFixed(2) : 0;
    const percentageField = document.getElementById('percentage');
    if (percentageField) {
        percentageField.value = percentage;
        console.log('Percentage calculated:', percentage);
    } else {
        console.error('percentage field not found');
    }
}

function resetReportForm() {
    console.log('resetReportForm called');
    const form = document.getElementById('report-form');
    const formElement = document.getElementById('report-card-form');
    if (!form || !formElement) {
        console.error('report-form or report-card-form not found');
        alert('Error: Form not found. Please check the page structure.');
        return;
    }
    form.style.display = 'block';
    formElement.reset();
    document.getElementById('report-id').value = '';
    document.getElementById('subjects-container').innerHTML = '';
    document.getElementById('form-title').textContent = 'Generate New Report Card';
    document.getElementById('student_id').selectedIndex = 0;
    document.getElementById('semester').selectedIndex = 0;
    document.getElementById('roll_no').value = '';
    document.getElementById('email').value = '';
    document.getElementById('contact_no').value = '';
    document.getElementById('percentage').value = '';
    document.getElementById('behavior').value = '';
    document.getElementById('comments').value = '';
    console.log('Form reset');
}

function editStudent(id, username, name, roll_no, email, contact_no, semester) {
    console.log('editStudent called with id:', id);
    const form = document.getElementById('edit-student-form');
    if (!form) {
        console.error('edit-student-form not found');
        alert('Error: Edit student form not found.');
        return;
    }
    form.style.display = 'block';
    document.getElementById('edit-id').value = id;
    document.getElementById('edit-username').value = username;
    document.getElementById('edit-name').value = name;
    document.getElementById('edit-roll_no').value = roll_no;
    document.getElementById('edit-email').value = email;
    document.getElementById('edit-contact_no').value = contact_no;
    document.getElementById('edit-semester').value = semester;
    window.scrollTo({ top: form.offsetTop, behavior: 'smooth' });
    console.log('Student edit form populated');
}

function editMaterial(id, title, file_path, semester) {
    console.log('editMaterial called with id:', id);
    const form = document.getElementById('edit-material-form');
    if (!form) {
        console.error('edit-material-form not found');
        alert('Error: Edit material form not found.');
        return;
    }
    form.style.display = 'block';
    document.getElementById('edit-material-id').value = id;
    document.getElementById('edit-title').value = title;
    document.getElementById('edit-old_file_path').value = file_path;
    document.getElementById('edit-semester').value = semester;
    window.scrollTo({ top: form.offsetTop, behavior: 'smooth' });
    console.log('Material edit form populated');
}

function editReport(id, student_id, name, roll_no, email, contact_no, semester, subject_marks_json, percentage, behavior, comments) {
    console.log('editReport called with:', { id, student_id, name, roll_no, email, contact_no, semester, subject_marks_json, percentage, behavior, comments });
    const form = document.getElementById('report-form');
    const formElement = document.getElementById('report-card-form');
    if (!form || !formElement) {
        console.error('report-form or report-card-form not found');
        alert('Error: Report card form not found. Please check the page structure.');
        return;
    }
    form.style.display = 'block';
    document.getElementById('form-title').textContent = 'Edit Report Card';
    document.getElementById('report-id').value = id || '';
    document.getElementById('student_id').value = student_id || '';
    document.getElementById('roll_no').value = roll_no || '';
    document.getElementById('email').value = email || '';
    document.getElementById('contact_no').value = contact_no || '';
    document.getElementById('semester').value = semester || '';
    document.getElementById('percentage').value = percentage || '';
    document.getElementById('behavior').value = behavior || '';
    document.getElementById('comments').value = comments || '';
    try {
        updateSubjects(semester);
        const subject_marks = JSON.parse(subject_marks_json || '{}');
        console.log('Parsed subject_marks:', subject_marks);
        Object.keys(subject_marks).forEach(subject => {
            const cleanSubject = subject.replace(/[^a-zA-Z0-9]/g, '_');
            const field = document.getElementById(`subject_${cleanSubject}`);
            if (field) {
                field.value = subject_marks[subject] || 0;
                console.log(`Set ${cleanSubject} to ${subject_marks[subject]}`);
            } else {
                console.warn(`Field subject_${cleanSubject} not found`);
            }
        });
        calculatePercentage();
    } catch (e) {
        console.error('Error parsing subject_marks_json:', e);
        alert('Error loading subject marks. Please check the console for details.');
    }
    window.scrollTo({ top: form.offsetTop, behavior: 'smooth' });
    console.log('Report edit form populated');
}