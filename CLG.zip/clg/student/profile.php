<?php
// Start session if not already started
if (!session_id()) session_start();

// Redirect to login if user is not a student or session is invalid
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: /clg/login.php?error=" . urlencode("Please log in as a student."));
    exit();
}

// Include database connection
require_once '../db_connect.php';

$success = $error = "";
$user_id = (int)$_SESSION['user_id'];

/**
 * Fetches student profile data from the database
 * @param mysqli $conn Database connection object
 * @param int $user_id User ID from session
 * @return array|null Student data as associative array or null if not found
 */
function fetchStudentProfile($conn, $user_id) {
    // Prepare SQL query to join students and users tables
    $sql = "SELECT s.id, s.username, s.name, s.roll_no, s.email, s.contact_no, s.mother_name, s.father_name, s.caste, s.dob, s.stream, s.gender, s.surname, s.city, s.college, s.enrollment_no, s.profile_image 
            FROM students s 
            JOIN users u ON s.username = u.username 
            WHERE u.id = ? AND u.role = 'student'";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        // Log preparation error
        error_log("Prepare failed: " . $conn->error);
        return null;
    }
    $stmt->bind_param("i", $user_id);
    if (!$stmt->execute()) {
        // Log execution error
        error_log("Execute failed: " . $stmt->error);
        $stmt->close();
        return null;
    }
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        // Log if no student is found
        error_log("No student found for user_id: $user_id");
        $stmt->close();
        return null;
    }
    $student = $result->fetch_assoc();
    $stmt->close();
    return $student;
}

// Fetch initial student profile
$student = fetchStudentProfile($conn, $user_id);
if (!$student) {
    $conn->close();
    session_destroy();
    header("Location: /clg/login.php?error=" . urlencode("Student not found."));
    exit();
}

// Handle profile update form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    // Sanitize and retrieve form inputs
    $name = trim($_POST['name']);
    $mother_name = trim($_POST['mother_name']);
    $father_name = trim($_POST['father_name']);
    $caste = trim($_POST['caste']);
    $dob = trim($_POST['dob']);
    $stream = trim($_POST['stream']);
    $gender = trim($_POST['gender']);
    $surname = trim($_POST['surname']);
    $city = trim($_POST['city']);
    $college = trim($_POST['college']);
    $enrollment_no = trim($_POST['enrollment_no']);
    $contact_no = trim($_POST['contact_no']);
    $email = trim($_POST['email']);
    $roll_no = trim($_POST['roll_no']);
    $profile_image = $student['profile_image'];

    // Handle image upload if provided
    if (!empty($_FILES['profile_image']['name'])) {
        $allowed_types = ['image/jpeg', 'image/png'];
        $max_size = 2 * 1024 * 1024; // 2MB
        $upload_dir = 'C:/xampp/htdocs/clg/Uploads/';
        $file_type = $_FILES['profile_image']['type'];
        $file_size = $_FILES['profile_image']['size'];
        $file_tmp = $_FILES['profile_image']['tmp_name'];
        $file_ext = strtolower(pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION));
        $file_name = 'student_' . $student['id'] . '_' . time() . '.' . $file_ext;
        $file_path = '/clg/Uploads/' . $file_name;

        if (!in_array($file_type, $allowed_types)) {
            $error = "Invalid image format. Only JPEG and PNG are allowed.";
        } elseif ($file_size > $max_size) {
            $error = "Image size exceeds 2MB limit.";
        } elseif (!move_uploaded_file($file_tmp, $upload_dir . $file_name)) {
            $error = "Failed to upload image.";
        } else {
            $profile_image = $file_path;
        }
    }

    // Validate form inputs
    if (empty($error)) {
        if (empty($name) || empty($surname) || empty($contact_no) || empty($email) || empty($roll_no)) {
            $error = "Name, Surname, Contact Number, Email, and Roll Number are required.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format.";
        } elseif ($dob && !DateTime::createFromFormat('Y-m-d', $dob)) {
            $error = "Invalid date of birth format (use YYYY-MM-DD).";
        } elseif ($gender && !in_array($gender, ['Male', 'Female', 'Other'])) {
            $error = "Invalid gender selection.";
        } elseif ($enrollment_no && !preg_match('/^[A-Za-z0-9\-]+$/', $enrollment_no)) {
            $error = "Invalid enrollment number format.";
        } else {
            // Check for duplicate roll_no or email
            $sql = "SELECT id FROM students WHERE (roll_no = ? OR email = ?) AND id != ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssi", $roll_no, $email, $student['id']);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $error = "Roll Number or Email is already in use.";
            } else {
                // Update student profile in database
                $sql = "UPDATE students 
                        SET name = ?, mother_name = ?, father_name = ?, caste = ?, dob = ?, stream = ?, gender = ?, surname = ?, city = ?, college = ?, enrollment_no = ?, contact_no = ?, email = ?, roll_no = ?, profile_image = ? 
                        WHERE id = ? AND username = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sssssssssssssssis", $name, $mother_name, $father_name, $caste, $dob, $stream, $gender, $surname, $city, $college, $enrollment_no, $contact_no, $email, $roll_no, $profile_image, $student['id'], $student['username']);
                if ($stmt->execute()) {
                    $success = "Profile updated successfully.";
                    // Refresh student data after update
                    $student = fetchStudentProfile($conn, $user_id);
                    if (!$student) {
                        $error = "Error fetching updated profile data.";
                    }
                } else {
                    $error = "Error updating profile: " . $conn->error;
                }
            }
            $stmt->close();
        }
    }
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile - College Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
</head>
<body>
    <!-- Include sidebar navigation -->
    <?php include '../sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Student Profile</h1>
            <button id="sidebar-toggle" class="sidebar-toggle"><i class="fas fa-bars"></i></button>
        </div>
        <!-- Display success or error messages -->
        <?php if ($success) { echo "<p class='success'>$success</p>"; } ?>
        <?php if ($error) { echo "<p class='error'>$error</p>"; } ?>
        <div class="profile-container">
            <?php if ($student) { ?>
                <div class="profile-card">
                    <!-- Display profile image or default image -->
                    <img src="<?php echo htmlspecialchars($student['profile_image'] ?: '/clg/Uploads/profile.jpg'); ?>" alt="Profile Image" class="profile-image">
                    <h2><?php echo htmlspecialchars($student['name'] . ' ' . ($student['surname'] ?: '')); ?></h2>
                    <table class="profile-table">
                        <tbody>
                            <!-- Student Personal Details Section -->
                            <tr class="section-header">
                                <th colspan="2">Student Personal Details</th>
                            </tr>
                            <tr>
                                <td class="label">Name</td>
                                <td class="value"><?php echo htmlspecialchars($student['name'] ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Surname</td>
                                <td class="value"><?php echo htmlspecialchars($student['surname'] ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Caste</td>
                                <td class="value"><?php echo htmlspecialchars($student['caste'] ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Date of Birth</td>
                                <td class="value"><?php echo htmlspecialchars($student['dob'] ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Gender</td>
                                <td class="value"><?php echo htmlspecialchars($student['gender'] ?: 'N/A'); ?></td>
                            </tr>
                            <!-- Student Contact Information Section -->
                            <tr class="section-header">
                                <th colspan="2">Student Contact Information</th>
                            </tr>
                            <tr>
                                <td class="label">Email</td>
                                <td class="value"><?php echo htmlspecialchars($student['email'] ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Contact Number</td>
                                <td class="value"><?php echo htmlspecialchars($student['contact_no'] ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">City</td>
                                <td class="value"><?php echo htmlspecialchars($student['city'] ?: 'N/A'); ?></td>
                            </tr>
                            <!-- Student Academic Details Section -->
                            <tr class="section-header">
                                <th colspan="2">Student Academic Details</th>
                            </tr>
                            <tr>
                                <td class="label">Roll Number</td>
                                <td class="value"><?php echo htmlspecialchars($student['roll_no'] ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Stream</td>
                                <td class="value"><?php echo htmlspecialchars($student['stream'] ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">College</td>
                                <td class="value"><?php echo htmlspecialchars($student['college'] ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Enrollment Number</td>
                                <td class="value"><?php echo htmlspecialchars($student['enrollment_no'] ?: 'N/A'); ?></td>
                            </tr>
                            <!-- Parents Details Section -->
                            <tr class="section-header">
                                <th colspan="2">Parents Details</th>
                            </tr>
                            <tr>
                                <td class="label">Mother's Name</td>
                                <td class="value"><?php echo htmlspecialchars($student['mother_name'] ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Father's Name</td>
                                <td class="value"><?php echo htmlspecialchars($student['father_name'] ?: 'N/A'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="form-actions">
                        <button class="btn" onclick="document.getElementById('edit-profile-form').style.display='block'">Edit Profile</button>
                    </div>
                </div>
                <!-- Profile edit form -->
                <div id="edit-profile-form" class="form-container" style="display:none;">
                    <h2>Edit Profile</h2>
                    <form method="POST" action="" class="material-form" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="profile_image">Profile Image (JPEG/PNG, Max 2MB)</label>
                            <input type="file" id="profile_image" name="profile_image" accept="image/jpeg,image/png">
                        </div>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($student['name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="surname">Surname</label>
                            <input type="text" id="surname" name="surname" value="<?php echo htmlspecialchars($student['surname'] ?: ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="caste">Caste</label>
                            <input type="text" id="caste" name="caste" value="<?php echo htmlspecialchars($student['caste'] ?: ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="dob">Date of Birth (YYYY-MM-DD)</label>
                            <input type="date" id="dob" name="dob" value="<?php echo htmlspecialchars($student['dob'] ?: ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="gender">Gender</label>
                            <select id="gender" name="gender">
                                <option value="" <?php echo empty($student['gender']) ? 'selected' : ''; ?>>Select Gender</option>
                                <option value="Male" <?php echo $student['gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                                <option value="Female" <?php echo $student['gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>
                                <option value="Other" <?php echo $student['gender'] == 'Other' ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($student['email']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="contact_no">Contact Number</label>
                            <input type="text" id="contact_no" name="contact_no" value="<?php echo htmlspecialchars($student['contact_no']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="city">City</label>
                            <input type="text" id="city" name="city" value="<?php echo htmlspecialchars($student['city'] ?: ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="roll_no">Roll Number</label>
                            <input type="text" id="roll_no" name="roll_no" value="<?php echo htmlspecialchars($student['roll_no']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="stream">Stream</label>
                            <input type="text" id="stream" name="stream" value="<?php echo htmlspecialchars($student['stream'] ?: ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="college">College</label>
                            <input type="text" id="college" name="college" value="<?php echo htmlspecialchars($student['college'] ?: ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="enrollment_no">Enrollment Number</label>
                            <input type="text" id="enrollment_no" name="enrollment_no" value="<?php echo htmlspecialchars($student['enrollment_no'] ?: ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="mother_name">Mother's Name</label>
                            <input type="text" id="mother_name" name="mother_name" value="<?php echo htmlspecialchars($student['mother_name'] ?: ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="father_name">Father's Name</label>
                            <input type="text" id="father_name" name="father_name" value="<?php echo htmlspecialchars($student['father_name'] ?: ''); ?>">
                        </div>
                        <div class="form-actions">
                            <button type="submit" name="update_profile" class="btn">Save Changes</button>
                            <button type="button" class="btn btn-secondary" onclick="this.closest('.form-container').style.display='none'">Cancel</button>
                        </div>
                    </form>
                </div>
            <?php } else { ?>
                <p class="error">Unable to load profile data. Please try logging in again.</p>
            <?php } ?>
        </div>
    </div>
</body>
</html>