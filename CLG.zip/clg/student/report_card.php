<?php
if (!session_id()) session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: /clg/login.php?error=" . urlencode("Please log in as a student."));
    exit();
}

require_once '../db_connect.php';
require_once '../TCPDF/tcpdf.php'; // Updated TCPDF path

$user_id = (int)$_SESSION['user_id'];
$sql = "SELECT s.id, s.name, s.roll_no, s.email, s.contact_no FROM students s JOIN users u ON s.username = u.username WHERE u.id = ? AND u.role = 'student'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    $stmt->close();
    $conn->close();
    session_destroy();
    header("Location: /clg/login.php?error=" . urlencode("Student not found."));
    exit();
}
$student = $result->fetch_assoc();
$student_id = $student['id'];
$stmt->close();

// Handle PDF download
if (isset($_GET['action']) && $_GET['action'] === 'download' && isset($_GET['report_id'])) {
    $report_id = (int)$_GET['report_id'];
    $sql = "SELECT subject_marks, percentage, behavior, comments, created_at FROM report_cards WHERE id = ? AND student_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $report_id, $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $report = $result->fetch_assoc();
        $subject_marks = json_decode($report['subject_marks'], true) ?? [];
        $total_marks = array_sum(array_intersect_key($subject_marks, array_flip(['Python', 'Cyber_Security', 'Introduction_to_AI', 'J2EE'])));

        // Create PDF
        $pdf = new TCPDF();
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('College Management System');
        $pdf->SetTitle('Report Card');
        $pdf->SetMargins(15, 15, 15);
        $pdf->AddPage();
        $pdf->SetFont('helvetica', '', 12);

        // PDF content
        $html = '
        <h1 style="text-align: center;">Report Card</h1>
        <table border="1" cellpadding="5">
            <tr><th style="background-color: #f4f6f9;">Student Name</th><td>' . htmlspecialchars($student['name']) . '</td></tr>
            <tr><th style="background-color: #f4f6f9;">Roll No</th><td>' . htmlspecialchars($student['roll_no']) . '</td></tr>
            <tr><th style="background-color: #f4f6f9;">Email</th><td>' . htmlspecialchars($student['email']) . '</td></tr>
            <tr><th style="background-color: #f4f6f9;">Contact No</th><td>' . htmlspecialchars($student['contact_no'] ?? 'N/A') . '</td></tr>
            <tr><th style="background-color: #f4f6f9;">Date Generated</th><td>' . date('d/m/Y h:i A', strtotime($report['created_at'])) . '</td></tr>
            <tr><th style="background-color: #f4f6f9;">Percentage</th><td>' . htmlspecialchars($report['percentage']) . '%</td></tr>
            <tr><th style="background-color: #f4f6f9;">Total Marks</th><td>' . htmlspecialchars($total_marks) . ' out of ' . (count(['Python', 'Cyber_Security', 'Introduction_to_AI', 'J2EE']) * 100) . '</td></tr>
            <tr><th style="background-color: #f4f6f9;">Behavior</th><td>' . htmlspecialchars($report['behavior']) . '</td></tr>
            <tr><th style="background-color: #f4f6f9;">Comments</th><td>' . htmlspecialchars($report['comments'] ?? 'N/A') . '</td></tr>
        </table>
        <h3 style="margin-top: 20px;">Subject Marks</h3>
        <table border="1" cellpadding="5">
            <tr><th style="background-color: #f4f6f9;">Subject</th><th style="background-color: #f4f6f9;">Marks</th></tr>';
        foreach (['Python', 'Cyber_Security', 'Introduction_to_AI', 'J2EE'] as $subject) {
            $html .= '<tr><td>' . $subject . '</td><td>' . ($subject_marks[$subject] ?? 'N/A') . '</td></tr>';
        }
        $html .= '</table>';

        $pdf->writeHTML($html, true, false, true, false, '');
        $pdf->Output('report_card_' . $report_id . '.pdf', 'D');
        $stmt->close();
        exit();
    } else {
        $error = "Report card not found.";
        error_log("Invalid report_id: $report_id for student_id: $student_id");
    }
    $stmt->close();
}

$sql = "SELECT id, subject_marks, percentage, behavior, comments, created_at FROM report_cards WHERE student_id = ? ORDER BY id DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$report_cards = $stmt->get_result();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Cards - College Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Modal styling */
        .modal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }
        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            width: 80%;
            max-width: 600px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            position: relative;
        }
        .close-modal {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #333;
        }
        .close-modal:hover {
            color: #dc3545;
        }
        .view-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .view-table th, .view-table td {
            border: 1px solid #e2e8f0;
            padding: 10px;
            text-align: left;
            color: #000; /* Black font color */
        }
        .view-table th {
            background-color: #f4f6f9;
            font-weight: 500;
        }
    </style>
    <script>
        const defaultSubjects = ['Python', 'Cyber_Security', 'Introduction_to_AI', 'J2EE'];

        function showViewModal(data) {
            const modal = document.getElementById('viewModal');
            const modalContent = document.getElementById('modalContent');
            const subjectMarks = JSON.parse(data.subject_marks.replace(/\\'/g, "'"));
            let totalMarks = defaultSubjects.reduce((sum, subject) => sum + (subjectMarks[subject] !== undefined ? parseFloat(subjectMarks[subject]) || 0 : 0), 0);

            let html = `
                <h2>View Report Card</h2>
                <table class="view-table">
                    <tr><th>Student Name</th><td>${data.name}</td></tr>
                    <tr><th>Roll No</th><td>${data.roll_no}</td></tr>
                    <tr><th>Email</th><td>${data.email}</td></tr>
                    <tr><th>Contact No</th><td>${data.contact_no}</td></tr>
                    <tr><th>Date Generated</th><td>${data.created_at_formatted}</td></tr>
                    <tr><th>Percentage</th><td>${data.percentage}%</td></tr>
                    <tr><th>Total Marks</th><td>${totalMarks} out of ${defaultSubjects.length * 100}</td></tr>
                    <tr><th>Behavior</th><td>${data.behavior}</td></tr>
                    <tr><th>Comments</th><td>${data.comments || 'N/A'}</td></tr>
                </table>
                <div style="margin-top: 20px;"></div>
                <h3>Subject Marks</h3>
                <table class="view-table">
                    <tr><th>Subject</th><th>Marks</th></tr>
            `;
            defaultSubjects.forEach(subject => {
                html += `<tr><td>${subject}</td><td>${subjectMarks[subject] !== undefined ? subjectMarks[subject] : 'N/A'}</td></tr>`;
            });
            html += '</table>';

            modalContent.innerHTML = html;
            modal.style.display = 'block';
        }

        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.view-report-btn').forEach(button => {
                button.addEventListener('click', () => {
                    const data = {
                        id: button.getAttribute('data-id'),
                        name: button.getAttribute('data-name'),
                        roll_no: button.getAttribute('data-roll_no'),
                        email: button.getAttribute('data-email'),
                        contact_no: button.getAttribute('data-contact_no'),
                        created_at_formatted: button.getAttribute('data-created_at_formatted'),
                        percentage: button.getAttribute('data-percentage'),
                        behavior: button.getAttribute('data-behavior'),
                        comments: button.getAttribute('data-comments'),
                        subject_marks: button.getAttribute('data-subject_marks')
                    };
                    showViewModal(data);
                });
            });

            document.querySelector('.close-modal').addEventListener('click', () => {
                document.getElementById('viewModal').style.display = 'none';
            });
        });
    </script>
</head>
<body>
    <?php include '../sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Report Cards</h1>
            <button id="sidebar-toggle" class="sidebar-toggle"><i class="fas fa-bars"></i></button>
        </div>
        <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>
        <div class="report-card-container">
            <h2>Your Report Cards</h2>
            <?php if ($report_cards->num_rows > 0): ?>
                <?php $latest_report = $report_cards->fetch_assoc(); ?>
                <div class="summary">
                    <h2>Date of Latest Report: <?php echo date('d/m/Y h:i A', strtotime($latest_report['created_at'])); ?></h2>
                </div>
                <?php $report_cards->data_seek(0); // Reset pointer to reuse result set ?>
            <?php endif; ?>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Roll No</th>
                        <th>Total Marks</th>
                        <th>Percentage</th>
                        <th>Behavior</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $report_cards->fetch_assoc()) { 
                        $subject_marks = json_decode($row['subject_marks'], true) ?? [];
                        $total_marks = array_sum(array_intersect_key($subject_marks, array_flip(['Python', 'Cyber_Security', 'Introduction_to_AI', 'J2EE'])));
                        $subject_marks_json = json_encode($subject_marks, JSON_HEX_APOS | JSON_HEX_QUOT);
                        $created_at_formatted = date('d/m/Y h:i A', strtotime($row['created_at']));
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($student['name']); ?></td>
                            <td><?php echo htmlspecialchars($student['roll_no']); ?></td>
                            <td><?php echo htmlspecialchars($total_marks); ?> out of <?php echo count(['Python', 'Cyber_Security', 'Introduction_to_AI', 'J2EE']) * 100; ?></td>
                            <td><?php echo htmlspecialchars($row['percentage']); ?>%</td>
                            <td><?php echo htmlspecialchars($row['behavior']); ?></td>
                            <td class="action-buttons">
                                <button class="btn btn-small btn-view view-report-btn" 
                                        data-id="<?php echo $row['id']; ?>" 
                                        data-name="<?php echo htmlspecialchars(addslashes($student['name'])); ?>" 
                                        data-roll_no="<?php echo htmlspecialchars(addslashes($student['roll_no'])); ?>" 
                                        data-email="<?php echo htmlspecialchars(addslashes($student['email'])); ?>" 
                                        data-contact_no="<?php echo htmlspecialchars(addslashes($student['contact_no'] ?? 'N/A')); ?>" 
                                        data-created_at_formatted="<?php echo $created_at_formatted; ?>" 
                                        data-percentage="<?php echo $row['percentage']; ?>" 
                                        data-behavior="<?php echo htmlspecialchars(addslashes($row['behavior'])); ?>" 
                                        data-comments="<?php echo htmlspecialchars(addslashes($row['comments'] ?? '')); ?>" 
                                        data-subject_marks='<?php echo $subject_marks_json; ?>'>
                                        <i class="fas fa-eye"></i> View
                                </button>
                                <a href="?action=download&report_id=<?php echo $row['id']; ?>" class="btn btn-small btn-secondary"><i class="fas fa-download"></i> Download</a>
                            </td>
                        </tr>
                    <?php } ?>
                    <?php if ($report_cards->num_rows === 0): ?>
                        <tr><td colspan="6">No report cards available</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div id="viewModal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div id="modalContent"></div>
        </div>
    </div>
</body>
</html>