<?php
if (!session_id()) session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: /clg/login.php?error=" . urlencode("Please log in as a student."));
    exit();
}

require_once '../db_connect.php';

$upload_dir = "C:/xampp/htdocs/clg/Uploads/"; // Absolute path for server
$relative_upload_dir = "/clg/Uploads/"; // Relative path for DB

// Handle file serving for view and download
if (isset($_GET['action']) && isset($_GET['file_id'])) {
    $action = $_GET['action'];
    $file_id = (int)$_GET['file_id'];

    // Fetch file path from database
    $sql = "SELECT file_path FROM materials WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $file_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $file_path = $result->fetch_assoc()['file_path'];
        $absolute_file_path = str_replace($relative_upload_dir, $upload_dir, $file_path);

        if (file_exists($absolute_file_path)) {
            header('Content-Type: application/pdf');
            header('Content-Length: ' . filesize($absolute_file_path));
            if ($action === 'download') {
                header('Content-Disposition: attachment; filename="' . basename($absolute_file_path) . '"');
            } else {
                header('Content-Disposition: inline; filename="' . basename($absolute_file_path) . '"');
            }
            readfile($absolute_file_path);
            $stmt->close();
            exit();
        } else {
            $error = "File not found on server.";
            error_log("File not found: $absolute_file_path");
        }
    } else {
        $error = "Invalid file ID.";
        error_log("Invalid file_id: $file_id");
    }
    $stmt->close();
}

$user_id = (int)$_SESSION['user_id'];
$sql = "SELECT s.id FROM students s JOIN users u ON s.username = u.username WHERE u.id = ? AND u.role = 'student'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    $stmt->close();
    $conn->close();
    session_destroy();
    header("Location: /clg/login.php?error=" . urlencode("Student not found."));
    exit();
}
$student = $result->fetch_assoc();
$student_id = $student['id'];
$stmt->close();

// Fetch all materials
$sql = "SELECT id, title, file_path FROM materials";
$stmt = $conn->prepare($sql);
$stmt->execute();
$materials_result = $stmt->get_result();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Materials - College Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
</head>
<body>
    <?php include '../sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Course Materials</h1>
            <button id="sidebar-toggle" class="sidebar-toggle"><i class="fas fa-bars"></i></button>
        </div>
        <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>
        <div class="material-container">
            <h2>Available Materials</h2>
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($materials_result->num_rows > 0) {
                        while ($row = $materials_result->fetch_assoc()) {
                            $absolute_file_path = str_replace($relative_upload_dir, $upload_dir, $row['file_path']);
                            $file_exists = file_exists($absolute_file_path);
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['title']); ?></td>
                                <td class="actions">
                                    <?php if ($file_exists) { ?>
                                        <a href="?action=view&file_id=<?php echo $row['id']; ?>" target="_blank" class="btn btn-small btn-view"><i class="fas fa-eye"></i> View</a>
                                        <a href="?action=download&file_id=<?php echo $row['id']; ?>" class="btn btn-small btn-secondary"><i class="fas fa-download"></i> Download</a>
                                    <?php } else { ?>
                                        <span class="error"><i class="fas fa-exclamation-circle"></i> File not found</span>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php }
                    } else { ?>
                        <tr><td colspan="2">No materials available</td></tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>