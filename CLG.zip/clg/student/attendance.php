<?php
if (!session_id()) session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: /clg/login.php?error=" . urlencode("Please log in as a student."));
    exit();
}

require_once '../db_connect.php';

$user_id = (int)$_SESSION['user_id'];
$sql = "SELECT s.id, s.name FROM students s JOIN users u ON s.username = u.username WHERE u.id = ? AND u.role = 'student'";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("Prepare failed: " . $conn->error);
    header("Location: /clg/login.php?error=" . urlencode("Database error."));
    exit();
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    $stmt->close();
    $conn->close();
    session_destroy();
    header("Location: /clg/login.php?error=" . urlencode("Student not found."));
    exit();
}
$student = $result->fetch_assoc();
$student_id = $student['id'];
$student_name = $student['name'];
$stmt->close();

$success = $error = "";
$current_date = date('Y-m-d');
$is_submitting = false;

// Check if attendance has already been submitted for today
$sql = "SELECT id FROM attendance WHERE student_id = ? AND date = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("Prepare failed: " . $conn->error);
    $conn->close();
    header("Location: /clg/login.php?error=" . urlencode("Database error."));
    exit();
}
$stmt->bind_param("is", $student_id, $current_date);
$stmt->execute();
$existing_attendance = $stmt->get_result();
$can_submit = $existing_attendance->num_rows === 0;
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_attendance']) && $can_submit) {
    $status = isset($_POST['status']) && $_POST['status'] === 'Confirm' ? 'Present' : 'Absent';
    $is_submitting = true;

    $conn->begin_transaction();
    try {
        $sql = "INSERT INTO attendance (student_id, date, time, status, pending_status) VALUES (?, ?, CURRENT_TIME, ?, 'Waiting')";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        $stmt->bind_param("iss", $student_id, $current_date, $status);
        if (!$stmt->execute()) {
            throw new Exception("Error submitting attendance: " . $conn->error);
        }
        $stmt->close();
        $conn->commit();
        $success = "Attendance submitted successfully. Waiting for teacher approval.";
        $can_submit = false;
        error_log("Attendance submitted: student_id=$student_id, date=$current_date, status=$status, pending_status=Waiting");
    } catch (Exception $e) {
        $conn->rollback();
        $error = $e->getMessage();
        error_log("Attendance submission error: " . $e->getMessage());
    }
    $is_submitting = false;
}

// Fetch attendance records
$sql = "SELECT date, status, pending_status FROM attendance WHERE student_id = ? ORDER BY date DESC";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("Prepare failed: " . $conn->error);
    $conn->close();
    header("Location: /clg/login.php?error=" . urlencode("Database error."));
    exit();
}
$stmt->bind_param("i", $student_id);
$stmt->execute();
$attendance_result = $stmt->get_result();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance - College Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
</head>
<body>
    <?php include '../sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Attendance</h1>
            <button id="sidebar-toggle" class="sidebar-toggle"><i class="fas fa-bars"></i></button>
        </div>
        <div class="attendance-container">
            <h2>Attendance Management</h2>
            <div class="attendance-grid">
                <div class="attendance-card">
                    <div class="date-banner">
                        <p class="date-text">Date: <?php echo htmlspecialchars(date('d/m/Y', strtotime($current_date))); ?></p>
                    </div>
                    <?php if ($success) { ?>
                        <p class="success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?></p>
                    <?php } ?>
                    <?php if ($error) { ?>
                        <p class="error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></p>
                    <?php } ?>
                    <?php if ($can_submit) { ?>
                        <form method="POST" action="" class="attendance-form">
                            <div class="status-buttons">
                                <button type="button" class="status-btn status-confirm" data-status="Confirm">
                                    <i class="fas fa-check-circle"></i> Confirm
                                </button>
                                <button type="button" class="status-btn status-decline" data-status="Decline">
                                    <i class="fas fa-times-circle"></i> Decline
                                </button>
                                <input type="hidden" name="status" id="status-input">
                            </div>
                            <div class="form-actions" style="text-align: center;">
                                <button type="submit" name="submit_attendance" class="btn btn-primary" <?php echo $is_submitting ? 'disabled' : ''; ?>>
                                    <?php echo $is_submitting ? '<i class="fas fa-spinner fa-spin"></i> Submitting...' : 'Submit Attendance'; ?>
                                </button>
                            </div>
                        </form>
                    <?php } else { ?>
                        <p class="info"><i class="fas fa-info-circle"></i> Attendance for today has already been submitted.</p>
                    <?php } ?>
                </div>
                <div class="attendance-card">
                    <h3>Attendance History</h3>
                    <div class="attendance-table-container">
                        <table class="attendance-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($attendance_result->num_rows > 0) {
                                    while ($row = $attendance_result->fetch_assoc()) { ?>
                                        <tr class="table-row">
                                            <td><?php echo htmlspecialchars(date('d/m/Y', strtotime($row['date'] ?? 'N/A'))); ?></td>
                                            <td class="status-<?php echo strtolower($row['pending_status'] === 'Waiting' ? 'waiting' : strtolower($row['status'] ?? 'absent')); ?>">
                                                <i class="fas <?php 
                                                    echo $row['pending_status'] === 'Waiting' ? 'fa-hourglass-half' : 
                                                        ($row['status'] === 'Present' ? 'fa-check-circle' : 'fa-times-circle'); ?>"></i>
                                                <?php echo htmlspecialchars($row['pending_status'] === 'Waiting' ? 'Waiting for Approval' : ($row['status'] ?? 'Absent')); ?>
                                            </td>
                                        </tr>
                                    <?php }
                                } else { ?>
                                    <tr class="table-row"><td colspan="2">No attendance records found.</td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const statusButtons = document.querySelectorAll('.status-btn');
            const statusInput = document.getElementById('status-input');

            statusButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const status = button.getAttribute('data-status');
                    statusInput.value = status;
                    statusButtons.forEach(btn => btn.classList.remove('selected'));
                    button.classList.add('selected');
                });
            });
        });
    </script>
</body>
</html>