<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: /clg/login.php?error=" . urlencode("Please log in as a student."));
    exit();
}

require_once '../db_connect.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$user_id = (int)$_SESSION['user_id'];

$sql = "SELECT s.name, s.roll_no, s.email, s.contact_no, r.* 
        FROM report_cards r 
        JOIN students s ON r.student_id = s.id 
        JOIN users u ON s.username = u.username 
        WHERE r.id = ? AND u.id = ? AND u.role = 'student'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id, $user_id);
$stmt->execute();
$report = $stmt->get_result()->fetch_assoc();
$stmt->close();
$conn->close();

if ($report) {
    require_once '../tcpdf/tcpdf.php';
    ob_end_clean();

    $subject_marks = json_decode($report['subject_marks'], true) ?? [];
    $default_subjects = ['Python', 'Cyber_Security', 'Introduction_to_AI', 'J2EE'];
    $total_marks = array_sum(array_intersect_key($subject_marks, array_flip($default_subjects)));

    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('H N Shukla College Of IT & Mgmt');
    $pdf->SetTitle('Student Report Card');
    $pdf->SetSubject('Report Card');
    $pdf->SetHeaderData('', 0, 'H N Shukla College Of IT & Mgmt', 'Report Card | Generated: ' . date('d/m/Y h:i A'));
    $pdf->setHeaderFont(['helvetica', '', 12]);
    $pdf->setFooterFont(['helvetica', '', 10]);
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
    $pdf->SetMargins(20, 30, 20);
    $pdf->SetHeaderMargin(15);
    $pdf->SetFooterMargin(15);
    $pdf->SetAutoPageBreak(TRUE, 20);
    $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 12);

    $html = '
    <style>
        body { font-family: Helvetica, Arial, sans-serif; }
        h1 { text-align: center; color: #1a202c; font-size: 18pt; margin-bottom: 10px; }
        h2 { text-align: center; color: #333; font-size: 14pt; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #000; padding: 8px; text-align: left; }
        th { background-color: #f4f6f9; font-weight: bold; }
        .section { margin-bottom: 15px; }
        .footer { text-align: center; font-size: 10pt; color: #555; margin-top: 20px; border-top: 1px solid #ccc; padding-top: 10px; }
    </style>
    <h1>' . htmlspecialchars($report['name']) . '</h1>
    <h2>H N Shukla College Of IT & Mgmt</h2>
    <div class="section">
        <table>
            <tr>
                <th>Roll No</th>
                <td>' . htmlspecialchars($report['roll_no']) . '</td>
            </tr>
            <tr>
                <th>Email</th>
                <td>' . htmlspecialchars($report['email']) . '</td>
            </tr>
            <tr>
                <th>Contact No</th>
                <td>' . htmlspecialchars($report['contact_no'] ?? 'N/A') . '</td>
            </tr>
        </table>
    </div>
    <div class="section">
        <table>
            <tr>
                <th>Date Generated</th>
                <td>' . date('d/m/Y h:i A', strtotime($report['created_at'])) . '</td>
            </tr>
            <tr>
                <th>Percentage</th>
                <td>' . htmlspecialchars($report['percentage']) . '%</td>
            </tr>
            <tr>
                <th>Total Marks</th>
                <td>' . htmlspecialchars($total_marks) . ' out of ' . (count($default_subjects) * 100) . '</td>
            </tr>
            <tr>
                <th>Behavior</th>
                <td>' . htmlspecialchars($report['behavior']) . '</td>
            </tr>
            <tr>
                <th>Comments</th>
                <td>' . htmlspecialchars($report['comments'] ?? 'N/A') . '</td>
            </tr>
        </table>
    </div>
    <div class="section">
        <table>
            <tr>
                <th>Subject</th>
                <th>Marks (out of 100)</th>
            </tr>';
    foreach ($default_subjects as $subject) {
        $html .= '
        <tr>
            <td>' . htmlspecialchars($subject) . '</td>
            <td>' . htmlspecialchars($subject_marks[$subject] ?? 0) . '</td>
        </tr>';
    }
    $html .= '</table>
    </div>
    <div class="footer">
        <p>Contact No: +12345 67890</p>
        <p>Email: hnshukla@gmail.com</p>
        <p>Address: 2, Raiya Rd, Vaishali Nagar, Rajkot, Gujarat 360007</p>
        <p>Generated on: ' . date('d/m/Y h:i A') . '</p>
    </div>';

    $pdf->writeHTML($html, true, false, true, false, '');
    $pdf->Output('report_card_' . $report['roll_no'] . '_' . $id . '.pdf', 'D');
    exit();
} else {
    header("Location: /clg/report_card.php?error=" . urlencode("Report card not found."));
    exit();
}
?>