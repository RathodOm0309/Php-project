<?php
if (!session_id()) session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: /clg/login.php?error=" . urlencode("Please log in as an admin."));
    exit();
}
require_once '../db_connect.php';

$sql = "SELECT u.*, tp.* FROM users u LEFT JOIN teacher_profiles tp ON u.id = tp.user_id WHERE u.role = 'teacher'";
$result = $conn->query($sql);
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Teachers - CMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
</head>
<body>
    <?php include '../sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Manage Teachers</h1>
        </div>
        <div class="student-container">
            <h2>Teachers List</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Name</th>
                        <th>Subject</th>
                        <th>Experience</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['username']); ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['subject'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['experience_years'] ?? 'N/A'); ?> years</td>
                            <td class="actions">
                                <button class="btn btn-secondary" onclick="editTeacher(<?php echo $row['id']; ?>, '<?php echo addslashes($row['name']); ?>', '<?php echo addslashes($row['subject']); ?>', <?php echo $row['experience_years'] ?? 'null'; ?>)">Edit</button>
                                <button class="btn btn-danger" onclick="if(confirm('Are you sure?')) deleteTeacher(<?php echo $row['id']; ?>)">Delete</button>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
        function deleteTeacher(id) {
            if (confirm('Are you sure you want to delete this teacher?')) {
                window.location.href = `/clg/admin/delete_teacher.php?id=${id}`;
            }
        }
    </script>
</body>
</html>