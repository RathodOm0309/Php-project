<?php
if (!session_id()) session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: /clg/login.php?error=" . urlencode("Please log in as an admin."));
    exit();
}
require_once '../db_connect.php';

$sql = "SELECT s.*, c.name AS class_name FROM students s LEFT JOIN classes c ON s.class_id = c.id ORDER BY c.name ASC, s.name ASC";
$result = $conn->query($sql);
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students - CMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
</head>
<body>
    <?php include '../sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Manage Students</h1>
        </div>
        <div class="student-container">
            <h2>Students List</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Class</th>
                        <th>Roll No</th>
                        <th>Email</th>
                        <th>Contact</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['class_name'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['roll_no']); ?></td>
                            <td><?php echo htmlspecialchars($row['email'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['contact_no'] ?? 'N/A'); ?></td>
                            <td class="actions">
                                <button class="btn btn-secondary" onclick="editStudent(<?php echo $row['id']; ?>, '<?php echo addslashes($row['username']); ?>', '<?php echo addslashes($row['name']); ?>', '<?php echo addslashes($row['roll_no']); ?>', '<?php echo addslashes($row['email']); ?>', '<?php echo addslashes($row['contact_no']); ?>', '<?php echo $row['class_id'] ?? ''; ?>')">Edit</button>
                                <button class="btn btn-danger" onclick="if(confirm('Are you sure?')) deleteStudent(<?php echo $row['id']; ?>)">Delete</button>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
        function deleteStudent(id) {
            if (confirm('Are you sure you want to delete this student?')) {
                window.location.href = `/clg/admin/delete_student.php?id=${id}`;
            }
        }
    </script>
</body>
</html>