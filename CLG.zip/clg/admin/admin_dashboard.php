<!DOCTYPE html>
<html lang="en">
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Classes - CMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
</head>
<body>
    <?php include '../sidebar.php'; ?>

    <div class="content">
        <div class="header">
            <h1>Administrator Dashboard</h1>
            <div class="filter-section">
                <label for="filter">Filter:</label>
                <select id="filter" name="filter">
                    <option value="all">All</option>
                    <option value="today">Today</option>
                    <option value="week">This Week</option>
                </select>
            </div>
        </div>

        <div class="dashboard-container">
            <div class="dashboard-grid">
                <a href="/clg/admin/manage_classes.php" class="dashboard-card">
                    <i class="fas fa-chalkboard"></i>
                    <h3>Classes</h3>
                    <p>3</p>
                </a>
                <a href="/clg/admin/manage_class_arms.php" class="dashboard-card">
                    <i class="fas fa-sitemap"></i>
                    <h3>Class Arms</h3>
                    <p>4</p>
                </a>
                <a href="/clg/admin/manage_teachers.php" class="dashboard-card">
                    <i class="fas fa-chalkboard-teacher"></i>
                    <h3>Class Teachers</h3>
                    <p>4</p>
                </a>
                <a href="/clg/admin/manage_students.php" class="dashboard-card">
                    <i class="fas fa-users"></i>
                    <h3>Students</h3>
                    <p>16</p>
                </a>
                <a href="/clg/admin/manage_session_term.php" class="dashboard-card">
                    <i class="fas fa-calendar"></i>
                    <h3>Session & Terms</h3>
                    <p>2</p>
                </a>
                <a href="/clg/admin/manage_terms.php" class="dashboard-card">
                    <i class="fas fa-calendar-alt"></i>
                    <h3>Terms</h3>
                    <p>3</p>
                </a>
                <a href="/clg/admin/attendance.php" class="dashboard-card">
                    <i class="fas fa-calendar-check"></i>
                    <h3>Total Student Attendance</h3>
                    <p>53</p>
                </a>
            </div>
        </div>
    </div>

    <script>
        const sidebarToggle = document.createElement('button');
        sidebarToggle.className = 'sidebar-toggle';
        sidebarToggle.innerHTML = '<i class="fas fa-bars"></i>';
        document.querySelector('.header').prepend(sidebarToggle);

        sidebarToggle.addEventListener('click', () => {
            document.getElementById('sidebar').classList.toggle('active');
            document.querySelector('.content').classList.toggle('full-width');
        });

        if (window.innerWidth <= 768) {
            document.getElementById('sidebar').classList.add('hidden');
        }

        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                document.getElementById('sidebar').classList.remove('hidden', 'active');
                document.querySelector('.content').classList.remove('full-width');
            } else {
                document.getElementById('sidebar').classList.add('hidden');
            }
        });
    </script>
</body>
</html>