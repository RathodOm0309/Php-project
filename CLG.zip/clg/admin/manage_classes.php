<?php
if (!session_id()) session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: /clg/login.php?error=" . urlencode("Please log in as an admin."));
    exit();
}
require_once '../db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_class'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $sql = "INSERT INTO classes (name) VALUES (?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $stmt->close();
}

$sql = "SELECT * FROM classes ORDER BY name ASC";
$result = $conn->query($sql);
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Classes - CMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
</head>
<body>
    <?php include '../sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Manage Classes</h1>
        </div>
        <div class="student-container">
            <h2>Classes List</h2>
            <form method="POST" action="" class="form-actions">
                <div class="form-group">
                    <input type="text" name="name" placeholder="Enter class name" required>
                </div>
                <button type="submit" name="add_class" class="btn">Add Class</button>
            </form>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo $row['created_at']; ?></td>
                            <td class="actions">
                                <button class="btn btn-secondary" onclick="editClass(<?php echo $row['id']; ?>, '<?php echo addslashes($row['name']); ?>')">Edit</button>
                                <button class="btn btn-danger" onclick="if(confirm('Are you sure?')) deleteClass(<?php echo $row['id']; ?>)">Delete</button>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
        function editClass(id, name) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '';
            form.innerHTML = `<input type="hidden" name="id" value="${id}"><input type="text" name="name" value="${name}" required><button type="submit" name="edit_class">Save</button>`;
            document.querySelector('.form-actions').appendChild(form);
        }
        function deleteClass(id) {
            if (confirm('Are you sure you want to delete this class?')) {
                window.location.href = `/clg/admin/delete_class.php?id=${id}`;
            }
        }
    </script>
</body>
</html>