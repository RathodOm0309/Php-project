<?php
require_once 'db_connect.php';
if (!session_id()) session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: /clg/login.php?error=" . urlencode("Please log in as a student."));
    exit();
}



$user_id = (int)$_SESSION['user_id'];
$sql = "SELECT s.id, s.name FROM students s JOIN users u ON s.username = u.username WHERE u.id = ? AND u.role = 'student'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    $stmt->close();
    $conn->close();
    session_destroy();
    header("Location: /clg/login.php?error=" . urlencode("Student not found."));
    exit();
}
$student = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - College Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Welcome, <?php echo htmlspecialchars($student['name']); ?>!</h1>
            <button id="sidebar-toggle" class="sidebar-toggle"><i class="fas fa-bars"></i></button>
        </div>
        <div class="dashboard-container">
            <div class="dashboard-grid">
                <a href="/clg/student/profile.php" class="dashboard-card">
                    <i class="fas fa-user"></i>
                    <h3>Profile</h3>
                    <p>View and update your personal information.</p>
                </a>
                <a href="/clg/student/report_card.php" class="dashboard-card">
                    <i class="fas fa-file-alt"></i>
                    <h3>Report Cards</h3>
                    <p>Check your academic performance.</p>
                </a>
                <a href="/clg/student/materials.php" class="dashboard-card">
                    <i class="fas fa-book"></i>
                    <h3>Course Materials</h3>
                    <p>Access study materials and resources.</p>
                </a>
                <a href="/clg/student/attendance.php" class="dashboard-card">
                    <i class="fas fa-calendar-check"></i>
                    <h3>Attendance</h3>
                    <p>Track your attendance records.</p>
                </a>
            </div>
        </div>
    </div>
</body>
</html>