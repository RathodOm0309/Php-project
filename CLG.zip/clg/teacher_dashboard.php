<?php
require_once 'db_connect.php';
if (!session_id()) session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: /clg/login.php?error=" . urlencode("Please log in as a teacher."));
    exit();
}


$user_id = (int)$_SESSION['user_id'];
$sql = "SELECT u.username, t.name FROM users u LEFT JOIN teacher_profiles t ON u.id = t.user_id WHERE u.id = ? AND u.role = 'teacher'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    $stmt->close();
    $conn->close();
    session_destroy();
    header("Location: /clg/login.php?error=" . urlencode("Teacher not found."));
    exit();
}
$teacher = $result->fetch_assoc();
$stmt->close();

// Fetch dashboard stats
$sql = "SELECT COUNT(*) AS total_students FROM students";
$result = $conn->query($sql);
$total_students = $result->fetch_assoc()['total_students'];

$sql = "SELECT COUNT(*) AS total_materials FROM materials WHERE uploaded_by = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_materials = $stmt->get_result()->fetch_assoc()['total_materials'];
$stmt->close();

$sql = "SELECT COUNT(*) AS total_reports FROM report_cards";
$result = $conn->query($sql);
$total_reports = $result->fetch_assoc()['total_reports'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard - College Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/clg/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="/clg/scripts.js" defer></script>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <div class="header">
            <h1>Welcome, <?php echo htmlspecialchars($teacher['name'] ?? $teacher['username']); ?></h1>
            <button id="sidebar-toggle" class="sidebar-toggle"><i class="fas fa-bars"></i></button>
        </div>
        <div class="dashboard-container">
            <div class="dashboard-grid">
                <a href="/clg/teacher/profile.php" class="dashboard-card">
                    <i class="fas fa-user"></i>
                    <h3>Profile</h3>
                    <p>View and update your personal information.</p>
                </a>
                <a href="/clg/teacher/manage_students.php" class="dashboard-card">
                    <i class="fas fa-users"></i>
                    <h3>Manage Students</h3>
                    <p>Add, edit, or delete student records (<?php echo $total_students; ?> students).</p>
                </a>
                <a href="/clg/teacher/manage_materials.php" class="dashboard-card">
                    <i class="fas fa-book"></i>
                    <h3>Manage Materials</h3>
                    <p>Upload and manage course materials (<?php echo $total_materials; ?> materials).</p>
                </a>
                <a href="/clg/teacher/report_card.php" class="dashboard-card">
                    <i class="fas fa-file-alt"></i>
                    <h3>Manage Report Cards</h3>
                    <p>Create and manage student report cards (<?php echo $total_reports; ?> reports).</p>
                </a>
            </div>
        </div>
    </div>
</body>
</html>