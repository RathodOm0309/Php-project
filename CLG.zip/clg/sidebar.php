<?php
if (!session_id()) session_start();
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
$current_page = basename($_SERVER['PHP_SELF']);
?>

<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <h2>CMS</h2>
    </div>
    <nav class="sidebar-nav">
        <ul>
            <?php if ($role === 'admin') { ?>
                <li>
                    <a href="/clg/admin/admin_dashboard.php" class="<?php echo $current_page == 'admin_dashboard.php' ? 'active' : ''; ?>">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                </li>
                <li class="menu-item">
                    <div class="menu-toggle <?php echo in_array($current_page, ['manage_classes.php', 'manage_students.php', 'manage_teachers.php']) ? 'active' : ''; ?>">
                        <span><i class="fas fa-cog"></i> Management</span>
                        <i class="fas fa-chevron-down arrow"></i>
                    </div>
                    <ul class="submenu <?php echo in_array($current_page, ['manage_classes.php', 'manage_students.php', 'manage_teachers.php']) ? 'active' : ''; ?>">
                        <li>
                            <a href="/clg/admin/manage_classes.php" class="<?php echo $current_page == 'manage_classes.php' ? 'active' : ''; ?>">
                                <i class="fas fa-chalkboard"></i> Classes
                            </a>
                        </li>
                        <li>
                            <a href="/clg/admin/manage_students.php" class="<?php echo $current_page == 'manage_students.php' ? 'active' : ''; ?>">
                                <i class="fas fa-users"></i> Students
                            </a>
                        </li>
                        <li>
                            <a href="/clg/admin/manage_teachers.php" class="<?php echo $current_page == 'manage_teachers.php' ? 'active' : ''; ?>">
                                <i class="fas fa-chalkboard-teacher"></i> Teachers
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="/clg/logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            <?php } elseif ($role === 'teacher') { ?>
                <li>
                    <a href="/clg/teacher_dashboard.php" class="<?php echo $current_page == 'teacher_dashboard.php' ? 'active' : ''; ?>">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                </li>
                <li class="menu-item">
                    <div class="menu-toggle <?php echo in_array($current_page, ['profile.php', 'manage_students.php', 'manage_materials.php', 'report_card.php', 'manage_attendance.php', 'timetable.php']) ? 'active' : ''; ?>">
                        <span><i class="fas fa-tools"></i> Teacher Tools</span>
                        <i class="fas fa-chevron-down arrow"></i>
                    </div>
                    <ul class="submenu <?php echo in_array($current_page, ['profile.php', 'manage_students.php', 'manage_materials.php', 'report_card.php', 'manage_attendance.php', 'timetable.php']) ? 'active' : ''; ?>">
                        <li>
                            <a href="/clg/teacher/profile.php" class="<?php echo $current_page == 'profile.php' ? 'active' : ''; ?>">
                                <i class="fas fa-user"></i> Profile
                            </a>
                        </li>
                        <li>
                            <a href="/clg/teacher/manage_students.php" class="<?php echo $current_page == 'manage_students.php' ? 'active' : ''; ?>">
                                <i class="fas fa-users"></i> Students
                            </a>
                        </li>
                        <li>
                            <a href="/clg/teacher/manage_materials.php" class="<?php echo $current_page == 'manage_materials.php' ? 'active' : ''; ?>">
                                <i class="fas fa-book"></i> Materials
                            </a>
                        </li>
                        <li>
                            <a href="/clg/teacher/report_card.php" class="<?php echo $current_page == 'report_card.php' ? 'active' : ''; ?>">
                                <i class="fas fa-file-alt"></i> Report Cards
                            </a>
                        </li>
                        <li>
                            <a href="/clg/teacher/manage_attendance.php" class="<?php echo $current_page == 'manage_attendance.php' ? 'active' : ''; ?>">
                                <i class="fas fa-calendar-check"></i> Attendance
                            </a>
                        </li>
                        
                    </ul>
                </li>
                <li>
                    <a href="/clg/logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            <?php } elseif ($role === 'student') { ?>
                <li>
                    <a href="/clg/student_dashboard.php" class="<?php echo $current_page == 'student_dashboard.php' ? 'active' : ''; ?>">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                </li>
                <li class="menu-item">
                    <div class="menu-toggle <?php echo in_array($current_page, ['profile.php', 'materials.php', 'report_card.php', 'attendance.php']) ? 'active' : ''; ?>">
                        <span><i class="fas fa-book-open"></i> Resources</span>
                        <i class="fas fa-chevron-down arrow"></i>
                    </div>
                    <ul class="submenu <?php echo in_array($current_page, ['profile.php', 'materials.php', 'report_card.php', 'attendance.php']) ? 'active' : ''; ?>">
                        <li>
                            <a href="/clg/student/profile.php" class="<?php echo $current_page == 'profile.php' ? 'active' : ''; ?>">
                                <i class="fas fa-user"></i> Profile
                            </a>
                        </li>
                        <li>
                            <a href="/clg/student/materials.php" class="<?php echo $current_page == 'materials.php' ? 'active' : ''; ?>">
                                <i class="fas fa-book"></i> Materials
                            </a>
                        </li>
                        <li>
                            <a href="/clg/student/report_card.php" class="<?php echo $current_page == 'report_card.php' ? 'active' : ''; ?>">
                                <i class="fas fa-file-alt"></i> Report Card
                            </a>
                        </li>
                        <li>
                            <a href="/clg/student/attendance.php" class="<?php echo $current_page == 'attendance.php' ? 'active' : ''; ?>">
                                <i class="fas fa-calendar-check"></i> Attendance
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="/clg/logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            <?php } else { ?>
                <li>
                    <a href="/clg/login.php">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </a>
                </li>
            <?php } ?>
        </ul>
    </nav>
</div>