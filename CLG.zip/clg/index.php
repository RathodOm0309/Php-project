<?php
if (!session_id()) session_start();

// Redirect authenticated users to their respective dashboards
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: /clg/admin/dashboard.php");
    } elseif ($_SESSION['role'] === 'teacher') {
        header("Location: /clg/teacher_dashboard.php");
    } else {
        header("Location: /clg/student_dashboard.php");
    }
    exit();
}

// Contact form handling
$errors = [];
$success = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $message = htmlspecialchars(trim($_POST['message']));
    
    if (empty($name) || strlen($name) < 2) {
        $errors[] = "Please enter a valid name.";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }
    if (empty($message) || strlen($message) < 10) {
        $errors[] = "Please enter a message with at least 10 characters.";
    }

    if (empty($errors)) {
        $success = "Thank you for your message! We'll get back to you soon.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Sunrise Institute of Technology</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            line-height: 1.6;
            color: #2d3748;
            background-color: #f7fafc;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header */
        .header {
            background: linear-gradient(90deg, #a3bffa, #c6d8ff);
            color: #2d3748;
            padding: 1.5rem 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .header h1 i {
            color: #fbbc05;
        }

        nav ul {
            list-style: none;
            display: flex;
            gap: 2rem;
        }

        nav ul li a {
            color: #000000ff;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.1rem;
            transition: color 0.3s ease;
        }

        nav ul li a:hover {
            color: #fbbc05;
        }

            nav ul li a.btn {
                background-color: #fbbc05;
                color: #2d3748;
                padding: 0.6rem 1.5rem;
                border-radius: 10px;
                font-weight: 600;
                font-size: 15px;
                transition: all 0.3s ease;
                width: 200px; /* You can adjust this value */
                display: inline-block; /* Needed to apply width on <a> elements */
                text-align: center;     /* Optional: centers the text horizontally */
            }

        nav ul li a.btn:hover {
            background-color: #f6e05e;
            transform: translateY(-2px);
        }

        /* Hero Slider */
        .hero {
            position: relative;
            height: 600px;
            overflow: hidden;
        }

        .slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 0.5s ease-in-out;
            background-size: cover;
            background-position: center;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #fff;
        }

        .slide.active {
            opacity: 1;
        }

        .slide-content {
            background: rgba(0, 0, 0, 0.5);
            padding: 2.5rem;
            border-radius: 12px;
        }

        .slide-content h2 {
            font-size: 2.8rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .slide-content p {
            font-size: 1.2rem;
            margin-bottom: 1.5rem;
        }

        .btn-primary {
            background-color: #fbbc05;
            color: #2d3748;
            padding: 0.8rem 2rem;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #f6e05e;
            transform: translateY(-2px);
        }

        /* About Section */
        .about {
            padding: 5rem 0;
            background-color: #fff;
            text-align: center;
        }

        .about h2 {
            font-size: 2.5rem;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 1.5rem;
        }

        .about p {
            max-width: 900px;
            margin: 0 auto;
            color: #4a5568;
            font-size: 1.1rem;
            line-height: 1.8;
        }

        /* Courses Section */
        .courses {
            padding: 5rem 0;
            background: linear-gradient(180deg, #edf2f7, #e2e8f0);
            text-align: center;
        }

        .courses h2 {
            font-size: 2.5rem;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 1.5rem;
        }

        .course-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }

        .course-item {
            background: #fff;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .course-item:hover {
            transform: translateY(-5px);
        }

        .course-item i {
            font-size: 2.5rem;
            color: #a3bffa;
            margin-bottom: 1rem;
        }

        .course-item h3 {
            font-size: 1.6rem;
            font-weight: 600;
            color: #2d3748;
            margin-bottom: 0.8rem;
        }

        .course-item p {
            color: #4a5568;
            font-size: 1rem;
        }

        /* Gallery Section */
        .gallery {
            padding: 5rem 0;
            background-color: #fff;
            text-align: center;
        }

        .gallery h2 {
            font-size: 2.5rem;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 1.5rem;
        }

        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
        }

        .gallery-item img {
            width: 100%;
            height: 220px;
            object-fit: cover;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .gallery-item img:hover {
            transform: scale(1.03);
        }

        /* Testimonials Section */
        .testimonials {
            padding: 5rem 0;
            background: linear-gradient(180deg, #edf2f7, #e2e8f0);
            text-align: center;
        }

        .testimonials h2 {
            font-size: 2.5rem;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 1.5rem;
        }

        .testimonial-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }

        .testimonial-item {
            background: #fff;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .testimonial-item:hover {
            transform: translateY(-5px);
        }

        .testimonial-item p {
            font-style: italic;
            color: #4a5568;
            margin-bottom: 1rem;
        }

        .testimonial-item h4 {
            font-size: 1.2rem;
            font-weight: 600;
            color: #2d3748;
        }

        /* Placement Section */
        .placement {
            padding: 5rem 0;
            background-color: #fff;
            text-align: center;
        }

        .placement h2 {
            font-size: 2.5rem;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 1.5rem;
        }

        .placement-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2rem;
        }

        .placement-item {
            background: #f7fafc;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .placement-item:hover {
            transform: translateY(-5px);
        }

        .placement-item i {
            font-size: 2.5rem;
            color: #a3bffa;
            margin-bottom: 1rem;
        }

        .placement-item h3 {
            font-size: 1.6rem;
            font-weight: 600;
            color: #2d3748;
            margin-bottom: 0.8rem;
        }

        .placement-item p {
            color: #4a5568;
        }

        /* Contact Section */
        .contact {
            padding: 5rem 0;
            background: linear-gradient(180deg, #e2e8f0, #edf2f7);
            text-align: center;
        }

        .contact h2 {
            font-size: 2.5rem;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 1.5rem;
        }

        .contact-form {
            max-width: 600px;
            margin: 0 auto;
        }

        .form-group {
            margin-bottom: 1.5rem;
            text-align: left;
        }

        .form-group label {
            display: block;
            font-weight: 600;
            color: #2d3748;
            margin-bottom: 0.5rem;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus,
        .form-group textarea:focus {
            border-color: #a3bffa;
            outline: none;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 120px;
        }

        .form-error {
            color: #e53e3e;
            font-size: 0.9rem;
            margin-top: 0.5rem;
            display: none;
        }

        .error, .success {
            color: #e53e3e;
            font-size: 1rem;
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .success {
            color: #38a169;
        }

        button {
            width: 100%;
            padding: 0.8rem;
            background-color: #a3bffa;
            color: #2d3748;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        button:hover {
            background-color: #c6d8ff;
            transform: translateY(-2px);
        }

        /* Footer */
        .footer {
            background: linear-gradient(90deg, #a3bffa, #c6d8ff);
            color: #2d3748;
            padding: 2.5rem 0;
            text-align: center;
        }

        .footer .container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            align-items: start;
        }

        .footer h3 {
            font-size: 1.4rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .footer ul {
            list-style: none;
        }

        .footer ul li {
            margin-bottom: 0.8rem;
        }

        .footer ul li a {
            color: #2d3748;
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.3s ease;
        }

        .footer ul li a:hover {
            color: #fbbc05;
        }

        .footer .social-links {
            display: flex;
            gap: 1rem;
            justify-content: center;
        }

        .footer .social-links a {
            font-size: 1.5rem;
            color: #2d3748;
            background: #fbbc05;
            width: 35px;
            height: 35px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s ease;
        }

        .footer .social-links a:hover {
            background-color: #f6e05e;
            transform: translateY(-2px);
        }

        .footer .copyright {
            grid-column: 1 / -1;
            margin-top: 1.5rem;
            font-size: 0.9rem;
            border-top: 1px solid rgba(45, 55, 72, 0.2);
            padding-top: 1rem;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header .container {
                flex-direction: column;
                gap: 1rem;
            }

            nav ul {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .hero {
                height: 400px;
            }

            .slide-content h2 {
                font-size: 2rem;
            }

            .slide-content p {
                font-size: 1rem;
            }

            .gallery-item img {
                height: 180px;
            }

            .footer .container {
                grid-template-columns: 1fr;
                text-align: center;
            }

            .footer .social-links {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <h1><i class="fas fa-university"></i> Sunrise Institute</h1>
            <nav>
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#courses">Courses</a></li>
                    <li><a href="#gallery">Gallery</a></li>
                    <li><a href="#testimonials">Testimonials</a></li>
                    <li><a href="#placement">Placement</a></li>
                    <li><a href="#contact">Contact</a></li>
                    <li><a href="/clg/login.php" class="btn">Personal Login</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <!-- Hero Section -->
        <section class="hero" id="home">
            <div class="slide active" style="background-image: url('/clg/Uploads/1.jpg');">
                <div class="slide-content">
                    <h2>Welcome to Sunrise Institute</h2>
                    <p>Empowering futures through cutting-edge education and innovation.</p>
                </div>
            </div>
            <div class="slide" style="background-image: url('/clg/Uploads/2.jpg');">
                <div class="slide-content">
                    <h2>Excellence in Learning</h2>
                    <p>Join a vibrant community dedicated to academic and professional success.</p>
                </div>
            </div>
        </section>

        <!-- About Section -->
        <section class="about" id="about">
            <div class="container">
                <h2>About Sunrise Institute</h2>
                <p>Sunrise Institute of Technology is a leading educational institution dedicated to fostering innovation, academic excellence, and holistic development. With state-of-the-art facilities, world-class faculty, and a student-centric approach, we empower our students to achieve their full potential in a dynamic and inclusive learning environment.</p>
            </div>
        </section>

        <!-- Courses Section -->
        <section class="courses" id="courses">
            <div class="container">
                <h2>Our Courses</h2>
                <div class="course-grid">
                    <div class="course-item">
                        <i class="fas fa-laptop-code"></i>
                        <h3>Computer Science</h3>
                        <p>Master cutting-edge technologies like AI, ML, and cloud computing.</p>
                    </div>
                    <div class="course-item">
                        <i class="fas fa-microchip"></i>
                        <h3>Electronics Engineering</h3>
                        <p>Explore circuits, robotics, and embedded systems with hands-on projects.</p>
                    </div>
                    <div class="course-item">
                        <i class="fas fa-briefcase"></i>
                        <h3>Business Management</h3>
                        <p>Develop leadership and strategic skills for global business success.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Gallery Section -->
        <section class="gallery" id="gallery">
            <div class="container">
                <h2>Campus Gallery</h2>
                <div class="gallery-grid">
                    <div class="gallery-item"><img src="/clg/Uploads/01.jpg" alt="Campus Image 1"></div>
                    <div class="gallery-item"><img src="/clg/Uploads/02.jpg" alt="Campus Image 2"></div>
                    <div class="gallery-item"><img src="/clg/Uploads/03.jpg" alt="Campus Image 3"></div>
                    <div class="gallery-item"><img src="/clg/Uploads/04.jpg" alt="Campus Image 4"></div>
                    <div class="gallery-item"><img src="/clg/Uploads/05.jpg" alt="Campus Image 5"></div>
                </div>
            </div>
        </section>

        <!-- Testimonials Section -->
        <section class="testimonials" id="testimonials">
            <div class="container">
                <h2>What Our Students Say</h2>
                <div class="testimonial-grid">
                    <div class="testimonial-item">
                        <p>"Sunrise Institute transformed my career with hands-on learning and exceptional faculty support."</p>
                        <h4>John Doe, Alumni</h4>
                    </div>
                    <div class="testimonial-item">
                        <p>"The vibrant campus and industry connections helped me land my dream job at a top tech firm."</p>
                        <h4>Jane Smith, Class of 2024</h4>
                    </div>
                    <div class="testimonial-item">
                        <p>"The personalized mentorship and innovative curriculum gave me a competitive edge."</p>
                        <h4>Emily Brown, Current Student</h4>
                    </div>
                </div>
            </div>
        </section>

        <!-- Placement Section -->
        <section class="placement" id="placement">
            <div class="container">
                <h2>Our Placement Achievements</h2>
                <div class="placement-grid">
                    <div class="placement-item">
                        <i class="fas fa-briefcase"></i>
                        <h3>Top Recruiters</h3>
                        <p>Partnered with industry leaders like Google, Microsoft, and TCS.</p>
                    </div>
                    <div class="placement-item">
                        <i class="fas fa-graduation-cap"></i>
                        <h3>Career Guidance</h3>
                        <p>Personalized training and mentorship for career success.</p>
                    </div>
                    <div class="placement-item">
                        <i class="fas fa-trophy"></i>
                        <h3>100% Placement</h3>
                        <p>Consistent placement records with top-tier opportunities.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Contact Section -->
        <section class="contact" id="contact">
            <div class="container">
                <h2>Contact Us</h2>
                <?php if (!empty($errors)): ?>
                    <?php foreach ($errors as $error): ?>
                        <p class="error"><?php echo $error; ?></p>
                    <?php endforeach; ?>
                <?php elseif ($success): ?>
                    <p class="success"><?php echo $success; ?></p>
                <?php endif; ?>
                <form class="contact-form" id="contact-form" method="POST" action="">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" placeholder="Your Name" required>
                        <span class="form-error" id="name-error">Please enter a valid name.</span>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="Your Email" required>
                        <span class="form-error" id="email-error">Please enter a valid email address.</span>
                    </div>
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea id="message" name="message" placeholder="Your Message" required></textarea>
                        <span class="form-error" id="message-error">Please enter a message with at least 10 characters.</span>
                    </div>
                    <button type="submit">Send Message</button>
                </form>
            </div>
        </section>
    </main>

    <footer class="footer">
        <div class="container">
            <div>
                <h3>Sunrise Institute</h3>
                <p>Empowering Futures Since 2000</p>
            </div>
            <div>
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#courses">Courses</a></li>
                    <li><a href="#gallery">Gallery</a></li>
                    <li><a href="#testimonials">Testimonials</a></li>
                    <li><a href="#placement">Placement</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </div>
            <div>
                <h3>Contact Info</h3>
                <ul>
                    <li><i class="fas fa-map-marker-alt"></i> 123 Sunrise Campus, Tech City</li>
                    <li><i class="fas fa-phone"></i> +1 234 567 8900</li>
                    <li><i class="fas fa-envelope"></i> <a href="mailto:info@sunrise.edu">info@sunrise.edu</a></li>
                </ul>
            </div>
            <div>
                <h3>Follow Us</h3>
                <div class="social-links">
                    <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                    <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                    <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            <p class="copyright">&copy; <?php echo date("Y"); ?> Sunrise Institute of Technology. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // Slider JavaScript
        const slides = document.querySelectorAll('.slide');
        let currentSlide = 0;

        function showSlide(index) {
            slides.forEach((slide, i) => {
                slide.classList.toggle('active', i === index);
            });
        }

        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }

        setInterval(nextSlide, 5000);
        showSlide(currentSlide);

        // Contact Form Validation
        const form = document.getElementById('contact-form');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            let isValid = true;

            const name = document.getElementById('name');
            const email = document.getElementById('email');
            const message = document.getElementById('message');
            const nameError = document.getElementById('name-error');
            const emailError = document.getElementById('email-error');
            const messageError = document.getElementById('message-error');

            nameError.style.display = 'none';
            emailError.style.display = 'none';
            messageError.style.display = 'none';

            if (name.value.trim().length < 2) {
                nameError.style.display = 'block';
                isValid = false;
            }

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email.value.trim())) {
                emailError.style.display = 'block';
                isValid = false;
            }

            if (message.value.trim().length < 10) {
                messageError.style.display = 'block';
                isValid = false;
            }

            if (isValid) {
                form.submit();
            }
        });
    </script>
</body>
</html>