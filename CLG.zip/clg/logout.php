<?php
if (!session_id()) session_start();
session_destroy();
header("Location: /clg/index.php");
exit();
?>